<?php session_start(); ?>
<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
<!DOCTYPE html>
<?php
include('header.php');
?>
 <?php
    include("srconfig.php");
?>
<body>
    <div class="nav-menu">
        <div class="bg transition">
            <div class="container-fluid fixed">
                <div class="row">
                    <div class="col-md-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="/"><img src="smoothrepairs_logo.png" class="white" alt="smoothrepairs logo"></a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="icon-menu"></span>
              </button>
                            <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                   <!-- <li class="nav-item active">
                                         <a class="nav-link" href="#id01" onclick="document.getElementById('id01').style.display='block'">Login</a>
                                    </li>-->
                                    <li class="nav-item active">
                                        <a class="nav-link btn-danger top-btn" href="artisan.php">Sign up</a>
                                    </li>
                                    
                                    
                                    <!--<li class="nav-item dropdown">
                                        <a class="nav-link" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Pages
                    <span class="icon-arrow-down"></span>
                  </a>
                                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </li>-->
                                    <li class="nav-item active">
                                        <a class="nav-link" href="contact.php">Contact Us</a>
                                    </li>
                                    <li class="nav-item active">
                                        <a class="nav-link" href="about.php">About Us</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="/blog">Blog</a>
                                    </li>
                                   <!--<li><a href="#" class="btn btn-outline-light top-btn"><span class="ti-plus"></span> Add Listing</a></li>-->
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>


<!-- Hero-area -->
		<div class="hero-area section">

			<!-- Backgound Image -->
			<div class="bg-image bg-parallax overlay" style="background-image:url(img1/page-background.jpg)"></div>
			<!-- /Backgound Image -->

			<div class="container">
				<div class="row">
					<div class="col-md-10 col-md-offset-1 text-center">
						<ul class="hero-area-tree">
						<br/><br/>
							<li><a href="index.php">Home</a></li>
							<li>Frequently Asked Questions</li>
						
						</ul>
						<h1 class="white-text">Frequently Asked Questions</h1>

					</div>
				</div>
			</div>

		</div>
		<!-- /Hero-area -->
		<div>
		    <section class="main-block">
        <div class="container">
            <div class="row"><h2 class="w3-center">Frequently Asked Questions on SmoothRepairs</h2></div><div></section>
<section class="main-block download-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">

<button onclick="myAccFunc('Demo1')" class="w3-padding-8 w3-theme w3-button w3-block w3-left-align">What is SmoothRepairs?</button>
<div id="Demo1" class="w3-hide">
  <div class="w3-container">
    <p>SmoothRepairs is an on-demand service that enables users to request professional artisans/technicians to carry out home and office repairs. Our artisans carry out maintenance, renovation, repair and installation services in a professional and efficient manner.<br>
We offer business to business (B2B) and business to consumer (B2C) facility management services and we are spread across the 36 states of Nigeria.
</p>
  </div>
</div>
<button onclick="myAccFunc('Demo2')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">How do I request a service?</button>
<div id="Demo2" class="w3-hide">
  <div class="w3-container">
    <p>Complete the details of the task to be done on the website - repairs, installation, service or inspection. Click on your required service. Select the information that applies to your request. You will be required to select your location, type of task and when you need the task to be executed.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo3')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">I requested a service, what next?</button>
<div id="Demo3" class="w3-hide">
  <div class="w3-container">
    <p>You will receive a confirmation email immediately which gives you a summary of your booking request. We will attend to your request within 10 minutes from the time that you requested our service and assign an artisan to you accordingly.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo4')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">What time can I book a service?</button>
<div id="Demo4" class="w3-hide">
  <div class="w3-container">
    <p>Our professional artisans are available 24 hours a day, 7 days a week. Bookings can be made 24 hours a day via the website. However, after 5pm each day bookings will get attention on the following day. You will still get request notification via your email.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo5')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">How can I give feedback on the service rendered by SmoothRepairs artisan?</button>
<div id="Demo5" class="w3-hide">
  <div class="w3-container">
    <p>Shortly after the completion of your task, you get a Job Completion Certificate (JCC) form from our artisan to review the job done by rating him. This enables us to continuously improve our service. We always look forward to receiving your feedback. </p>
  </div>
</div>
<button onclick="myAccFunc('Demo6')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">What happens if I need an additional task to be performed?</button>
<div id="Demo6" class="w3-hide">
  <div class="w3-container">
    <p>If you would like an additional task to be performed, you may simply speak with SmoothRepairs on 08113975299 or 09087222874 between 8:00 am and 5:00 pm, Mondays to Fridays to request your additional task. Whichever way, you need to notify SmoothRepairs to ensure operational transparency.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo7')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">Can I cancel or reschedule my booking?</button>
<div id="Demo7" class="w3-hide">
  <div class="w3-container">
    <p>We understand that schedules change and life happens. You can reschedule your service booking. You can give us a call and also make a new request.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo8')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">Who do you offer your services to?</button>
<div id="Demo8" class="w3-hide">
  <div class="w3-container">
    <p>SmoothRepairs offers its services to corporate organizations (B2B) and individuals (B2C). We are open to strategic business partnerships with corporate organizations across the federation.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo9')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">Do I have to be at home during the execution of my task?</button>
<div id="Demo9" class="w3-hide">
  <div class="w3-container">
    <p>It is advisable for you to be present and supervise the artisan. However, you may assign a representative to oversee your project based on your requirements. Ultimately, our service aims at providing you with more freedom in your daily routine. We always encourage you to communicate your preferences clearly to our artisans to ensure satisfactory results.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo10')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">What happens if the task takes more time than projected?</button>
<div id="Demo10" class="w3-hide">
  <div class="w3-container">
    <p>In case an artisan needs more time to complete a task, you will be informed about that early enough and you can decide if you want to hire such for longer period than the estimated time. We do not charge extra for extra time.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo11')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">What happens if I am dissatisfied with the quality of service?</button>
<div id="Demo11" class="w3-hide">
  <div class="w3-container">
    <p>We always ensure that our artisans perform tasks to the best of their proven ability in order to satisfy you. However, if you are dissatisfied with any service performance, please inform us within 48 hours after the task is done. We will explore all available options to resolve your complaint.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo12')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">Does SmoothRepairs offer re-work and warranty?</button>
<div id="Demo12" class="w3-hide">
  <div class="w3-container">
    <p>We offer “2 days re-work warranty” on installations services only. If you have any reason to call for a re-work, please communicate with us within 2 days on 08113975299 or 09087222874.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo13')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">Can I contact the artisan directly?</button>
<div id="Demo13" class="w3-hide">
  <div class="w3-container">
    <p>We strongly advise our customers not to contact an artisan directly. This measure serves to protect you as our customer in the event of a poor service, conflict, theft or damages to your property. Always contact SmoothRepairs on our official lines or our social media channels.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo14')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">How much does a service booking cost?</button>
<div id="Demo14" class="w3-hide">
  <div class="w3-container">
    <p>Service booking is free. You are guaranteed the deployment of a verified and reliable SmoothRepairs artisan to your location. </p>
  </div>
</div>
<button onclick="myAccFunc('Demo15')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">How much does a service cost?</button>
<div id="Demo15" class="w3-hide">
  <div class="w3-container">
    <p>Service cost varies for each request booking. Our fees are very affordable. Please know that most services require consultation/inspection before a fee is given. Service costs may vary upon inspection, type and scope of work. We do not give quotes before work begins at your location.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo16')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">How do I pay for a service?</button>
<div id="Demo16" class="w3-hide">
  <div class="w3-container">
    <p>You can only pay through your preferred means into our corporate account. </p>
  </div>
</div>
<button onclick="myAccFunc('Demo17')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">Are there any hidden charges?</button>
<div id="Demo17" class="w3-hide">
  <div class="w3-container">
    <p>No, there are no hidden charges. Once your order is confirmed, an artisan is sent to you for appropriate inspection. You then receive a detailed invoice with all the particulars of your order. </p>
  </div>
</div>
<button onclick="myAccFunc('Demo18')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">Do I receive an invoice?</button>
<div id="Demo18" class="w3-hide">
  <div class="w3-container">
    <p>Yes, you will receive an email of your invoice at the email address you provided upon booking after the inspection of your appliance. The invoice contains your service request particulars.</p>
  </div>
</div>
<button onclick="myAccFunc('Demo19')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">How reliable and trustworthy are your workers?</button>
<div id="Demo19" class="w3-hide">
  <div class="w3-container">
    <p>•	Our artisans are recommended to us by homeowners, registered trade associations, certified vocational centres, technical colleges and our parent company,<a href="https://www.icsoutsourcing.com"> ICS Outsourcing.</a> <br>
    •	Our artisans are tested carefully on their professional skills. We conduct background checks thoroughly before they are approved by SmoothRepairs. We personally engage every prospective artisan and vet their qualifications. </p>
  </div>
</div>
<button onclick="myAccFunc('Demo20')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">How can I become a SmoothRepairs artisan?</button>
<div id="Demo20" class="w3-hide">
  <div class="w3-container">
    <p>You can register directly on our website by signing up<a href="https://www.smoothrepairs.com/artisan"> here</a>. </p>
  </div>
</div>
<button onclick="myAccFunc('Demo21')" class="w3-padding-16 w3-theme w3-button w3-block w3-left-align">How do I know if I am successfully registered as an artisan?</button>
<div id="Demo21" class="w3-hide">
  <div class="w3-container">
    <p>You will get SMS and email notifications as a SmoothRepairs artisan.</p>
  </div>
</div>
</div></div></div>
</section>

<!-- Script for Sidebar, Tabs, Accordions, Progress bars and slideshows -->
<script>

// Side navigation
function w3_open() {
    var x = document.getElementById("mySidebar");
    x.style.width = "100%";
    x.style.fontSize = "40px";
    x.style.paddingTop = "10%";
    x.style.display = "block";
}
function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
}

// Tabs
function openCity(evt, cityName) {
  var i;
  var x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  var activebtn = document.getElementsByClassName("testbtn");
  for (i = 0; i < x.length; i++) {
      activebtn[i].className = activebtn[i].className.replace(" w3-dark-grey", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " w3-dark-grey";
}

var mybtn = document.getElementsByClassName("testbtn")[0];
mybtn.click();

// Accordions
function myAccFunc(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}

// Slideshows
var slideIndex = 1;

function plusDivs(n) {
slideIndex = slideIndex + n;
showDivs(slideIndex);
}

function showDivs(n) {
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length} ;
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block";  
}

showDivs(1);

// Progress Bars
function move() {
  var elem = document.getElementById("myBar");   
  var width = 5;
  var id = setInterval(frame, 10);
  function frame() {
    if (width == 100) {
      clearInterval(id);
    } else {
      width++; 
      elem.style.width = width + '%'; 
      elem.innerHTML = width * 1  + '%';
    }
  }
}
</script>                          
                                 </div>
                    
                
            
          

	
		</div>
		<!-- /Contact -->
		<!--============================= ADD LISTING =============================-->
     <!--//END CATEGORIES -->
	 
    <!--//END FEATURED PLACES -->
<section class="main-block" light-bg>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="add-listing-wrap">
                        <h2>Reach millions of people</h2>
                        <p>Add your skill in front of millions and earn 3x profits from our listing</p>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="featured-btn-wrap">
                        <a href="artisan.php" class="btn btn-danger"><span class="ti-plus"></span> Signup</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//END ADD LISTING -->
			<?php
		include('footer.php');
		?>
</body>

</html>