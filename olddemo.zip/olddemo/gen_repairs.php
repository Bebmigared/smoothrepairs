<?php 
include('srconfig.php');
     session_start();
	 error_reporting(E_ALL);
	   ini_set('display_errors',0);
?>
 <?php include('gtm.php'); ?>
 <?php
include('header.php');
?>
<!-- MultiStep Form -->
<link href="css/multi.css" rel="stylesheet">
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">-->
  <link href="css/select2.min.css" rel="stylesheet" />
<div class="row">
    <div class="col-md-12 col-md-offset-3">
        <form id="msform" action="" method="post">
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Gen. Type</li>
                <li>Select Location</li>
				<li>Area of Use</li>
				<li>Select Brand</li>
				<li>Select Capacity</li>
				<li>Take Action</li>
				<li>User Details</li>
            </ul>
            <!-- fieldsets -->
            <fieldset>
                <h2 class="fs-title">GENERATOR REPAIRS AND SERVICING</h2>
                <h3 class="fs-subtitle">NOTE: We will ask a few questions to connect you with the best Generator Repair Professionals you can trust.</h3>
                <label>What is the type of your generator?</label>
				<br><br>
				<div class="form-group">
				<label>Select</label><br>
				<select name="gen_type">
                                                <option>Diesel Generator</option>
                                                <option>Petrol Generator</option>
                                                <option>Gas Generator</option>
                                                
                                            </select>
               
				 </div>
                 <input type="button" name="next" class="next action-button" value="Next"/>
            </fieldset>
			<fieldset>
                <h2 class="fs-title">Select Your Location</h2>
                <label>Please provide the location where you require the service</label>
				<br>
				<div class="form-group">
				<label>Location</label>
				<br>
				<div class="form-group">
				<label class="control-label">Select Your State</label><br>
						   <select name="state" id="state">
							  <option value="" selected="selected" >- Select -</option>
							  <option value='Abia'>Abia</option>
							  <option value='Adamawa'>Adamawa</option>
							  <option value='Akwa Ibom'>Akwa Ibom</option>
							  <option value='Anambra'>Anambra</option>
							  <option value='Bauchi'>Bauchi</option>
							  <option value='Bayelsa'>Bayelsa</option>
							  <option value='Benue'>Benue</option>
							  <option value='Borno'>Borno</option>
							  <option value='Cross River'>Cross River</option>
							  <option value='Delta'>Delta</option>
							  <option value='Ebonyi'>Ebonyi</option>
							  <option value='Edo'>Edo</option>
							  <option value='Ekiti'>Ekiti</option>
							  <option value='Enugu'>Enugu</option>
							  <option value='FCT'>FCT</option>
							  <option value='Gombe'>Gombe</option>
							  <option value='Imo'>Imo</option>
							  <option value='Jigawa'>Jigawa</option>
							  <option value='Kaduna'>Kaduna</option>
							  <option value='Kano'>Kano</option>
							  <option value='Katsina'>Katsina</option>
							  <option value='Kebbi'>Kebbi</option>
							  <option value='Kogi'>Kogi</option>
							  <option value='Kwara'>Kwara</option>
							  <option value='Lagos'>Lagos</option>
							  <option value='Nasarawa'>Nasarawa</option>
							  <option value='Niger'>Niger</option>
							  <option value='Ogun'>Ogun</option>
							  <option value='Ondo'>Ondo</option>
							  <option value='Osun'>Osun</option>
							  <option value='Oyo'>Oyo</option>
							  <option value='Plateau'>Plateau</option>
							  <option value='Rivers'>Rivers</option>
							  <option value='Sokoto'>Sokoto</option>
							  <option value='Taraba'>Taraba</option>
							  <option value='Yobe'>Yobe</option>
							  <option value='Zamfara'>Zamafara</option>
							</select><br></div><div class="form-group">
						
						  
						
							  <label class="control-label">Select Your LGA</label><br>
							  <select name="lga" id="lga" required>
							  </select></div>
                </div>
				<input type="button" name="previous" class="previous action-button-previous" value="Previous"/>
                 <input type="button" name="next" class="next action-button" value="Next"/>
            </fieldset>
			<fieldset>
                <h2 class="fs-title">Select Area of Use</h2>
                <label>Please identify where your generator is being used</label>
				<br>
				<div class="form-group">
				<label>Area of Use</label>
				<br>
				<br>
				<select name="area_use">
                                                <option>Residential - I better pass my neighbor</option>
												<option>Residential building - up to five families</option>
												<option>Big residential apartments/offices</option>
												<option>Small office</option>
												<option>Corporate/Industrial building</option>
												
												
			</select>
			<label>Please provide little background on your request</label>
			<br>
			<textarea rows="3" name="message" placeholder="briefly describe your request" ></textarea>
			
			
                </div>
				<input type="button" name="previous" class="previous action-button-previous" value="Previous"/>
                 <input type="button" name="next" class="next action-button" value="Next"/>
            </fieldset>
			<fieldset>
                <h2 class="fs-title">Select Your Brand</h2>
                <label>What brand is the generator?</label>
				<br>
					<div class="form-group">
				<label>Select Your Brand</label>
				<br>
				<br>
				<select name="gen_brand">
                                                <option>Simba</option>
												<option>Tiger</option>
												<option>Mikano</option>
												<option>Firman</option>
												<option>Thermocool</option>
												<option>Honda</option>
												<option>Yamaha</option>
												<option>Perkins</option>
												<option>Other, user types</option>
												
												
												
			</select>
					</div>
				<input type="button" name="previous" class="previous action-button-previous" value="Previous"/>
                 <input type="button" name="next" class="next action-button" value="Next"/>
            </fieldset>
			<fieldset>
                <h2 class="fs-title">Select Capacity</h2>
                <label>How many KVA is the generator?</label>
				<br>
					<div class="form-group">
				<label>Select Your Generator Output Capacity</label>
				<br>
				<br>
				<select name="gen_capacity">
                                                <option>1 to 1.3 KVA</option>
												<option>2 to 2.5 KVA</option>
												<option>3 to 3.5 KVA</option>
												<option>4 to 4.5 KVA</option>
												<option>5 KVA</option>
												<option>6 KVA</option>
												<option>7 KVA</option>
												<option>8 KVA</option>
												<option>9 KVA</option>
												<option>10 KVA</option>
												<option>20 KVA</option>
												<option>25 KVA</option>
												<option>30 KVA</option>
												<option>50 KVA</option>
												<option>100 KVA</option>
												<option>200 KVA</option>
												<option>250 KVA</option>
												<option>500 KVA</option>
												<option>1000 KVA</option>
												<option>2000 KVA</option>
												<option>Other, user types</option>
												
												
												
			</select>
					</div>
				<input type="button" name="previous" class="previous action-button-previous" value="Previous"/>
                 <input type="button" name="next" class="next action-button" value="Next"/>
            </fieldset>
			<fieldset>
                <h2 class="fs-title">Take Action</h2>
					<div class="form-group">
				<label>What action are you taking now?</label>
				<br>
				<br>
				<select name="take_action">
                                                <option>Ready to hire</option>
												<option>Need inspection only</option>
												<option>Just checking prices and options</option>
												<option>Just checking how the website works</option>
												
				</select>
				<br>
				<label>How soon do you need the service?</label>
				<br>
				<br>
				<select name="how_soon">
                                                <option>At the earliest</option>
												<option>Within a week</option>
												<option>Within 2 weeks</option>
												<option>Later, not sure yet</option>
												
				</select>
					</div>
				<input type="button" name="previous" class="previous action-button-previous" value="Previous"/>
                 <input type="button" name="next" class="next action-button" value="Next"/>
            </fieldset>
			<fieldset>
                <h2 class="fs-title">User Details</h2>
                <h3 class="fs-subtitle">Fill in your credentials</h3>
                <input type="text" name="email" placeholder="Email" required />
                <input type="text" name="first_name" placeholder="First Name" required / >
				<input type="text" name="last_name" placeholder="Last Name"required / >
              <input type="text" name="phone_no" placeholder="Phone Number" required />
			  <br>
			<textarea rows="3" name="other_message" placeholder="Is there anything you would like the technician to know?" required ></textarea>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous"/>
                <input type="submit" name="submit" class="submit action-button" value="Submit"/>
            </fieldset>
			<?php
if(isset($_POST['submit'])){
	
	
	if(empty($_POST['other_message'])){
		 echo "Kindly supply additional info. to help service you better<br>";
			 }
			 else{
				 
				 $SERVICE_CATEGORY = "Generator Repairs & Servicing";
				 $REQUEST_DESCRIPTION = "Please provide little background on your request: ".$_POST['message']."<br>Is there anything you would like the technician to know? ".$_POST['other_message']."<br>Type of Generator: ".$_POST['gen_type']."<br>Area of Usage: ".$_POST['area_use']."<br> Generator Brand: ".$_POST['gen_brand']."<br> Generator Power Output: ".$_POST['gen_capacity']."<br> How ready are you to hire?: ".$_POST['how_soon']."<br>Next Step: ".$_POST['take_action'];
				 $email = $_POST['email'];
				 $mobile = $_POST['phone_no'];
				 $ORIGINATOR = $_POST['first_name'].", ". $_POST['last_name'];
			     $ORIGINATOR_ADDRESS = $_POST['state'].'-'.$_POST['lga'];
			     //$ORIGINATOR_ADDRESS = $_POST['lga'];
				 $REQUEST_DATE = date("Y-m-d H:i:s");
				$sql = mysql_query("INSERT INTO request_form(fullname,email,mobile,location,service_type,messages,date_req)VALUES('$ORIGINATOR','$email','$mobile','$ORIGINATOR_ADDRESS','$SERVICE_CATEGORY','$REQUEST_DESCRIPTION','$REQUEST_DATE')");
				if($sql){
				
				echo "<script type='text/javascript'>alert('Your SmoothRepairs Job Order has been submitted successfully')</script>";
				 $to = 'info@smoothrepairs.com';
				 $copy = $email;
				 $copy1 = 'lezinando@icsoutsourcing.com';
				 $copy2 = 'oakeredolu@icsoutsourcing.com';

        $subject = "SmoothRepairs Job Order for $ORIGINATOR ";
        //Admin Notification
        $message = "
        <html>
        <head>
        <title>SmoothRepairs Registration Job Request Notification</title>
        </head>
        <body>
        <p>Dear Admin,</p>
        <p>There is a pending Job Order for <strong>$ORIGINATOR</strong>.</p>
        <i>Request Brief:</i>
        <br>
        <br><strong>Originator:</strong> $ORIGINATOR
        <br><strong>Mobile:</strong> $mobile
        <br><strong>Email Address:</strong> $email
        <br><strong>Address:</strong> $ORIGINATOR_ADDRESS
        <br><strong>Service Type:</strong> $SERVICE_CATEGORY 
        <br><strong>Request Details:</strong> $REQUEST_DESCRIPTION
        <p>Best Regards,</p>
        <i>Customer Service,</i>
        <br><strong>SmoothRepairs</strong>
        <br>info@smoothrepairs.com
        <br>Mobile: 08113975299
        </body>
        </html>
        ";
        //User Notification
        $message2 = "
        <html>
        <head>
        <title>SmoothRepairs Registration Job Request Notification</title>
        </head>
        <body>
        <p>Dear $ORIGINATOR,</p>
        <p>Thank you for choosing SmoothRepairs, your reliable on-demand service.<strong></p>
        <br>
        <br>Your job order is currently being reviewed and a suitable artisan will be assigned to you shortly.
        <p>Best Regards,</p>
        <i>Customer Service,</i>
        <br><strong>SmoothRepairs</strong>
        <br>info@smoothrepairs.com
        <br>Mobile: 08113975299
        </body>
        </html>";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= 'From: SmoothRepairs Admin<info@smoothrepairs.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
         mail($copy,$subject,$message2,$headers);
         mail($copy1,$subject,$message,$headers);
         mail($copy2,$subject,$message,$headers);
					  header('Location: gen_repairs.php');
					  
					  
					  
$request = "";                                      //initialize the request variable
$param["user"] = "ics_limited";                     //this is the username of our smstorrent.net api account
$param["cypher"] = "ics_recruitment";               //this is the password of our smstorrent.net api account
$param["message"] = "Dear Admin, there is a $SERVICE_CATEGORY job request on SmoothRepairs by $ORIGINATOR ($mobile). Kindly sign in to view the order.";   //this is the message that we want to send
$param["recipient"] = "08113975299";                //these are the comma-separated recipients of the message
$param["sender"] = "S_Repairs";                        //this is our sender 
$param["redirect"]= "";                             //optional parameter if you want your script to handle the response.
$param["resp_type"]= "data";                        //optional parameter (data | html)

foreach($param as $key=>$val)               //traverse through each member of the param array
{ 
  $request.= $key."=".rawurlencode($val);       //we have to urlencode the values
  $request.= "&";                   //append the ampersand (&) sign after each paramter/value pair
}
$request = substr($request, 0, strlen($request)-1);     //remove the final ampersand sign from the request

//First prepare the info that relates to the connection
$host = "api.smstorrent.net";               //The API domain 
$script = "/http/";                 //the script location
$request_length = strlen($request);
$method = "POST";                   // must be POST if sending large no of  messages
if ($method == "GET"){
  $script .= "?$request";
}

//Now comes the header which we are going to post. 
$header = "$method $script HTTP/1.1\r\n";
$header .= "Host: $host\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: $request_length\r\n";
$header .= "Connection: close\r\n\r\n";
$header .= "$request\r\n";

//Now we open up the connection
$socket = @fsockopen($host, 80, $errno, $errstr); 
if ($socket) //if its open, then...
{ 
  fputs($socket, $header);          // send the details over
  while(!feof($socket))
  {
  }
  fclose($socket); 
} else {
    echo "SMS sending failed:: Reason: could not connect to gateway!";
    
    }					  
				 }
				 else{
				 

	echo "Unable to Process Request <br>";

					 
}
}
}
?>
        </form>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
         <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script> 
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
        <script src="js/lga.min.js"></script>
		
		 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
		  
        <!-- /.link to designify.me code snippets -->
    </div>
</div>
<!-- /.MultiStep Form -->
<script>

//jQuery time
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

$(".next").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	next_fs = $(this).parent().next();
	
	//activate next step on progressbar using the index of next_fs
	$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
	
	//show the next fieldset
	next_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale current_fs down to 80%
			scale = 1 - (1 - now) * 0.2;
			//2. bring next_fs from the right(50%)
			left = (now * 50)+"%";
			//3. increase opacity of next_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({
        'transform': 'scale('+scale+')',
        'position': 'absolute'
      });
			next_fs.css({'left': left, 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

$(".previous").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();
	
	//de-activate current step on progressbar
	$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
	
	//show the previous fieldset
	previous_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale previous_fs from 80% to 100%
			scale = 0.8 + (1 - now) * 0.2;
			//2. take current_fs to the right(50%) - from 0%
			left = ((1-now) * 50)+"%";
			//3. increase opacity of previous_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({'left': left});
			previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

$(".submit").click(function(){
	return true;
})
</script>