<?php session_start(); ?>
<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
<!DOCTYPE html>
<?php
include('header.php');
?>
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBO0cgbsapmKRr5Sq0BSnVeBNp3XxICpCM&callback=initMap" async defer></script>
 <script>
      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 19,
          center: {lat: 6.5485889, lng: 3.366240800000014}
        });

        var trafficLayer = new google.maps.TrafficLayer();
        trafficLayer.setMap(map);
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBO0cgbsapmKRr5Sq0BSnVeBNp3XxICpCM&callback=initMap">
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBO0cgbsapmKRr5Sq0BSnVeBNp3XxICpCM&v=3.exp&sensor=false&libraries=places"></script>
        <script>
            function init() {
                var input = document.getElementById('CITY');
                var autocomplete = new google.maps.places.Autocomplete(input);
                google.maps.event.addListener(autocomplete, 'place_changed',
        function() {
        var place = autocomplete.getPlace();
        var lat = place.geometry.location.lat();
        var lng = place.geometry.location.lng();
        
        document.getElementById("LATITUDE").value = lat
        document.getElementById("LONGITUDE").value = lng
   }
);
            }
 
            google.maps.event.addDomListener(window, 'load', init);
        </script>
        <script type="text/javascript">
function changetextbox()
{
    if (document.getElementById("CATEGORY").value == 'Others') {
        document.getElementById("OTHERS").disabled=false;


    }
    if (document.getElementById("CATEGORY").value != 'Others') {
        document.getElementById("OTHERS").disabled=true;


    } 
}
</script>
    <?php
    include("srconfig.php");
?>
<body>
    <?php
include('nav-menu.php');
?>
	 <!-- Modal for Login -->


<!-- Hero-area -->
		<div class="hero-area section">

			<!-- Backgound Image -->
			<div class="bg-image bg-parallax overlay" style="background-image:url(img1/page-background.jpg)"></div>
			<!-- /Backgound Image -->

			<div class="container">
				<div class="row">
					<div class="col-md-10 col-md-offset-1 text-center">
						<ul class="hero-area-tree">
						<br/><br/>
							<li><a href="index.php">Home</a></li>
							<li>Contact</li>
						</ul>
						<h1 class="white-text">Get In Touch</h1>

					</div>
				</div>
			</div>

		</div>
		<!-- /Hero-area -->

		<!-- Contact -->
		<div id="contact" class="section">

			<!-- container -->
			<div class="container">

				<!-- row -->
				<div class="row">

					<!-- contact form -->
					<div class="col-md-6">
						<div class="contact-form">
							<h4>Send A Message</h4>
							<form method="post" action="">
								<input class="input" type="text" name="name" placeholder="Name" required>
								<input class="input" type="email" name="email" placeholder="Email" required>
								<input class="input" type="text" name="subject" placeholder="Subject" required>
								<input class="input" type="text" name="phone" placeholder="Mobile No." required>
								<textarea class="input" name="message" placeholder="Enter your Message" required></textarea>
								<input type="date" name="REG_DATE" placeholder="yyyy-mm-dd" value="<?php echo date("Y-m-d");?>" hidden>
								<button type="submit" name="Submit" id="submit" class="main-button icon-button pull-right">Send Message</button>
							</form>
							<?php
        if (isset($_POST['Submit']))
            {
                
        include("srconfig.php");
        session_start();

        $NAME=$_POST['name'];
        $MESSAGE=$_POST['message'];
        $PHONE=$_POST['Phone'];
        $EMAIL=$_POST['email'];
        $SUBJECT=$_POST['subject'];
        $REG_DATE=$_POST['REG_DATE'];
        
        $sql = mysql_query("INSERT INTO contact_us(name,email,phone_no,subject,message,date_reg)VALUES('$NAME','$EMAIL','$PHONE','$SUBJECT','$MESSAGE','$REG_DATE')");
	
	
		$to = 'info@smoothrepairs.com';
        $subject = "$SUBJECT";

        $message = "
        <html>
        <head>
        <title>SmoothRepairs Inquiry for $NAME</title>
        </head>
        <body>
        <p>Dear SmoothRepairs Team,</p>
        <p>$NAME sent in an inquiry on $REG_DATE with the following details:</p>
        <p>$NAME</p>
        <p>$EMAIL</p>
        <p>$PHONE</p>
        <p>$MESSAGE</p>
        <p>Kindly review and contact the inquirer accordingly</p>
        <p>Best Regards,</p>
        <br><i>Ayodele Osho,</i>
        <br><strong>COO, SmoothRepairs</strong>
        <br>info@smoothrepairs.com
        <br>Mobile: 08113975299
        
        </body>
        </html>
        ";

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= 'From: SmoothRepairs Admin<info@smoothrepairs.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
        
        echo "<script type='text/javascript'>alert('Your message has been successfully sent to our SmoothRepairs team and you will be contacted shortly')</script>";
        echo "<script language='javascript' type='text/javascript'> location.href='http://www.smoothrepairs.com/' </script>";

        } 
        else {

        }
        ?>
						</div>
					</div>
					<!-- /contact form -->

					<!-- contact information -->
					<div class="col-md-5 col-md-offset-1">
						<h4>Contact Information</h4>
						<ul class="contact-details">
							<li><i class="fa fa-envelope"></i>info@smoothrepairs.com</li>
							<li><a href="https://api.whatsapp.com/send?phone=2348113975299"><i class="fa fa-whatsapp"></i></a>WhatsApp</li>
							<li><i class="fa fa-phone"></i>08090202323</li>
							<li><i class="fa fa-map-marker"></i>6 Olusoji Idowu St, Ilupeju 110001, Lagos</li>
						</ul>

						<!-- contact map -->
						<div id="map"></div>
						<!-- /contact map -->

					</div>
					<!-- contact information -->

				</div>
				<!-- /row -->

			</div>
			<!-- /container -->

		</div>
		<!-- /Contact -->
		<!--============================= ADD LISTING =============================-->
    
			<?php
		include('footer.php');
		?>
</body>

</html>