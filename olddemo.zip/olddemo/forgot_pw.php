<?php session_start();


?>

<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" type="image/x-icon" href="../../Smoothrepairs_favicon.jpg" />

    <title>User Login | SmoothRepairs Admin Dashboard </title>
    <script src='https://www.google.com/recaptcha/api.js'></script>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Reset Password</h3>
                    </div>
                    <div class="panel-body">
                        <form method="post" name="">
        <h5>Re-Send SmoothRepairs Credentials</h5>
                            <label for="email">Enter Registered Email</label>
                            <br><input class="input" id="email" name="email" type="text" placeholder="Enter Registered Email" required><br>
                            <button id="submit" name="submit" type="submit" value="Send Email" class="main-button icon-button pull-right">Reset Password</button>

                </form>
                            <?php
    if (isset($_POST['submit']))
        {     
    include("srconfig.php");
    $email=$_POST['email'];
    $query = mysql_query("SELECT * FROM Users WHERE EMAIL='$email' AND STATUS=1");
    $row = mysql_fetch_array($query);
    $USERNAME=$row['USERNAME'];
    $EMAIL=$row['EMAIL'];
    $PASSWORD=$row['PASSWORD'];
    $FIRST_NAME=$row['FIRST_NAME'];
    $LAST_NAME=$row['LAST_NAME'];
    
     if (mysql_num_rows($query) != 0)
    {
    echo "<script type='text/javascript'>alert('Your login credentials have been sent to your registered email address')</script>";
    
        $to = $EMAIL;
        $subject = "SmoothRepairs Login Credentials for $FIRST_NAME $LAST_NAME";

        $message = "
        <html>
        <head>
        <title>SmoothRepairs Login Credentials</title>
        </head>
        <body>
        <p>Dear $FIRST_NAME,</p>
        <p>Thanks for choosing <strong>SmoothRepairs</strong>.</p>
        <p>Welcome to the world of <strong>Exceptional Service Delivery</strong>.</p>
        <i>Your login credentials are as follows:</i>
        <br>
        <br>Username: $USERNAME 
        <br>Password: $PASSWORD
        <p>Please feel free to take advantage of our verified professionals anywhere, anytime!</p>
        <a href='http://www.smoothrepairs.com/login.php'>Click Here to Login to SmoothRepairs</a>
        <p>Best Regards,</p>
        <i>Admin Team,</i>
        <br><strong>SmoothRepairs</strong>
        <br>info@smoothrepairs.com
        <br>Mobile: 08113975299
        
        </body>
        </html>
        ";

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= 'From: SmoothRepairs Admin<info@smoothrepairs.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
    
    }
      else
      {
    echo "<script type='text/javascript'>alert('Invalid email address')</script>";
    }
    }
    
    ?>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
