<div id="id01" class="w3-modal">
    <div class="w3-modal-content w3-card-4 w3-animate-top">
      <header class="w3-container w3-theme-l1"><meta http-equiv="Content-Type" content="text/html; charset=shift_jis"> 
        <span onclick="document.getElementById('id01').style.display='none'"
        class="w3-button w3-display-topright">Close[ﾃ余</span>
        <h5>Sign-In to your SmoothRepairs Account</h5>
        </header>
      <div class="w3-padding">
          <div class="col-md-6">
		<div class="contact-form">
        <form method="post" name="">
            <label for="username">Username</label><br>
            <input class="input" id="username" name="username" type="text" placeholder="Enter Username"><br><br>
            <label for="password">Password</label><br>
            <input class="input"  id="password" name="password" type="password" placeholder="Enter Password">
            <br>
            <button class="main-button icon-button pull-right" id="submit" name="submit" type="submit">Sign-In &nbsp;&nbsp;</button>
            <br><br>
            <a href='forgot_pw.php'>Forgot Password?</a>
            <br>

                </form>
                </div>
                </div>
                <?php
    if (isset($_POST['submit']))
        {     
    include("srconfig.php");
    $username=$_POST['username'];
    $password=$_POST['password'];
    $_SESSION['login_user']=$username;
    $query = mysql_query("SELECT * FROM Users WHERE USERNAME='$username' AND PASSWORD='$password' AND STATUS=1");
    $row = mysql_fetch_array($query);
    $_SESSION['username']=$username;
    $_SESSION['loggedIn'] = true;
     if (mysql_num_rows($query) != 0)
    {
     if ($row['USER_TYPE'] =='User')
     {
         echo "<script language='javascript' type='text/javascript'> location.href='user_home.php' </script>";
     }
          if ($row['USER_TYPE']=='Artisan')
     {
         echo "<script language='javascript' type='text/javascript'> location.href='artisan_home.php' </script>";
     }
               if ($row['USER_TYPE']=='Admin')
     {
         echo "<script language='javascript' type='text/javascript'> location.href='home.php' </script>";
     }
     }
      else
      {
    echo "<script type='text/javascript'>alert('Username Or Password Invalid!')</script>";
    echo "<script language='javascript' type='text/javascript'> location.href='index.php' </script>";
    }
    }
    
    ?>
      </div>
      <footer class="w3-container w3-theme-l1">
        <p class="col-lg-8 col-sm-12 footer-text m-0 text-white">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved by <a href="http://www.icsoutsourcing.com" target="_blank">ICS Digital Solutions</a>
						</p>
      </footer>
    </div>
</div>