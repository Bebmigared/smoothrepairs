<?php session_start(); ?>
<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
<!DOCTYPE html>
<?php
include('header.php');
?>
 <?php
    include("srconfig.php");
?>
<body>
    <div class="nav-menu">
        <div class="bg transition">
            <div class="container-fluid fixed">
                <div class="row">
                    <div class="col-md-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="/"><img src="smoothrepairs_logo.png" class="white" alt="smoothrepairs logo"></a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="icon-menu"></span>
              </button>
                            <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                   <!-- <li class="nav-item active">
                                         <a class="nav-link" href="#id01" onclick="document.getElementById('id01').style.display='block'">Login</a>
                                    </li>-->
                                    <li class="nav-item active">
                                        <a class="nav-link btn-danger top-btn" href="artisan.php">Sign up</a>
                                    </li>
                                <!--<li class="nav-item dropdown">
                                        <a class="nav-link" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Pages
                    <span class="icon-arrow-down"></span>
                  </a>
                                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </li>-->
                                    <li class="nav-item active">
                                        <a class="nav-link" href="contact.php">Contact Us</a>
                                    </li>
                                    <li class="nav-item active">
                                        <a class="nav-link" href="about.php">About Us</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="/blog">Blog</a>
                                    </li>
                                   <!--<li><a href="#" class="btn btn-outline-light top-btn"><span class="ti-plus"></span> Add Listing</a></li>-->
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>


<!-- Hero-area -->
		<div class="hero-area section">

			<!-- Backgound Image -->
			<div class="bg-image bg-parallax overlay" style="background-image:url(img1/page-background.jpg)"></div>
			<!-- /Backgound Image -->

			<div class="container">
				<div class="row">
					<div class="col-md-10 col-md-offset-1 text-center">
						<ul class="hero-area-tree">
						<br/><br/>
							<li><a href="index.php">Home</a></li>
							<li>Terms & Conditions</li>
						
						</ul>
						<h1 class="white-text">SmoothRepairs Terms & Conditions</h1>

					</div>
				</div>
			</div>

		</div>
		<!-- /Hero-area -->
		    <section class="main-block">
        <div class="container">
            <div class="row"><h2 class="w3-center">SMOOTHREPAIRS TERMS & CONDITIONS</h2></div><div></section>
<!--<section class="main-block download-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">

                                 </div>
                    
                
            
          

	
		</div>
		</div>
		</section>-->
		
		<!-- Start download Area -->
			<section class="download-area section-gap" id="app">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 download-right">
							<h2>CONTRACTUAL RELATIONSHIP</h2>
							<p class="subs">
								These terms of service constitute a legally binding agreement (the “Agreement”) between you and ICS Outsourcing Limited, a company with its registered office at 6, Idowu Olusoji Idowu Street, Off Association Avenue, Ilupeju, 
								Lagos (“ICS Outsourcing”, “we”, “us” or “our”), by which expression includes our legal representatives, administrators, successors-in-interest, permitted assigns and affiliates (“Affiliates”).</p>
								<p> This Agreement governs your use of the SmoothRepairs platform for the purpose of carrying out repairs services as a SmoothRepairs Artisan (a “SmoothRepairs Artisan”, “Artisan” “You” “Your”) 
								to users (“Clients”) in whose locations ICS Outsourcing carries out repairs.</p>
If you do not agree to this Agreement, you may not access or use the SmoothRepairs Platform either as a Client or as an Artisan.</p>
<p>
This Agreement expressly supersedes prior agreements or arrangements with you. SmoothRepairs may immediately terminate this Agreement with respect to you, or generally
cease offering or deny access to the SmoothRepairs Platform or any portion thereof,at any time for any reason.</p>
<p>SmoothRepairs may amend this Agreement from time to time. Amendments will be effective upon SmoothRepairs posting of such updated Agreement at this location.
Your continued access or use of the SmoothRepairs Platform after such posting constitutes your consent to be bound by this Agreement, as amended.</p>
												
						</div>
						<div class="col-lg-6 download-right">
							<h2>OWNERSHIP</h2>
							<p class="subs">
								The SmoothRepairs Platform and all rights therein are and shall remain ICS Outsourcing Limited or the property of SmoothRepairs licensors.
								Neither this Agreement nor your use of the SmoothRepairs Platform conveys or grants to you any rights: </p>
<p>(i)	in or related to the SmoothRepairs Platform except for the limited license granted above; or
(ii)	 to use or reference in any manner SmoothRepairs company names, logos, product and service names, trademarks or services marks or those of SmoothRepairs licensors.

							</p>
												
						</div>
					</div>
				</div>	
			</section>
			<!-- End download Area -->
			<section class="main-block">
        <div class="container">
            <div class="row"><h2 class="w3-center">YOUR RELATIONSHIP WITH ICS OUTSOURCING AND SMOOTHREPAIRS CLIENTS</h2></div><div></section>
<!-- Start download Area -->
			<section class="main-block light-bg section-gap" id="app">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 download-right">
							<h2>1.	ARTISAN ONBOARDING POLICY</h2>
							<p class="subs">
								In order to use the SmoothRepairs Platform, you must register for and maintain an active personal user account (“Account”). 
								You must be at least 18 years to obtain an Account and hold a valid means of Identification. Our artisans must possess both technical and soft skills. 
								We need industry-certified professional artisans with a minimum of five years’ experience in their various fields. Hence, if you want to register with us, get your industry certificate ready. 
								In a bid to keep SmoothRepairs secure for both businesses and customers, we need you to provide verifiable data.</p>
								<p> Account registration requires you to submit to SmoothRepairs certain personal information, such as your name, address, mobile phone number, age, two guarantors and two referees. 
								Our collection and use of personal information in connection with the SmoothRepairs Platform is as provided in SmoothRepairs Privacy 
								Policy located at https://www.SmoothRepairs.com.</p>
        		</div>
						<div class="col-lg-6 download-right">
							<h2>2.	PAYMENTS</h2>
							<p class="subs">
								Artisans are expected to provide current and correct account details when registering on the SmoothRepairs platform. Artisans will be paid every two weeks by SmoothRepairs’ representatives.</p>
<p>The Artisans will be paid based on the amount stated on the quotations the Artisan provides after inspecting the repairs to be carried out at the Clients’ Locations.</p>
<p>The Artisans are not to demand nor receive money from the Clients.</p>
												
						</div>
					</div>
					<div class="row">
						<div class="col-lg-6 download-right">
							<h2>3.	PERFORMANCE REVIEWS</h2>
							<p class="subs">
							ICS Outsourcing reserves the right to review your performance from time to time while you are providing Repair Services.
							The Clients will be provided with a “Job Completion Certificate” to rate the services you provided and, in some cases, such a review may be carried out anonymously by SmoothRepairs personnel or by an independent third party contracted by ICS Outsourcing. 
							You understand and agree that we may collect personal information about you, including but not limited to images and videos, during such a review.
							As a result of any such review, we may restrict your access and use of the SmoothRepairs Platform and/or terminate this Agreement with you.</p>
        		</div>
						<div class="col-lg-6 download-right">
							<h2>4.	PROMOTIONAL ACTIVITIES</h2>
							<p class="subs">
								While providing Repair Service under the SmoothRepairs Platform, you will not promote or advertise companies or services which compete with SmoothRepairs. 
								Your failure to comply with the terms of this section may result in your inability to access and use the SmoothRepairs Platform or SmoothRepairs termination of this Agreement with you.</p>
												
						</div>
					</div>
					<div class="row">
						<div class="col-lg-6 download-right">
							<h2>5.	TOOLS MAINTENANCE AND EXPENSES</h2>
							<p class="subs">
							You will be exclusively responsible for the maintenance of your tools and for transportation expenses you accrue. 
							You will be responsible to obtain a full inspection of your tools from a service provider pre-approved by SmoothRepairs at least once in every calendar year. </p>
							<p>You represent, warrant and undertake that you will provide Repairs with Tools which: 
                        (i)	 are suitable in all material ways for carrying out repairs in Clients’ Locations;
                        (ii)	 are kept in good operating condition and meet the industry safety standards and; 
                        (iii)	 are lawfully operated by you.
</p>
        		</div>
						<div class="col-lg-6 download-right">
							<h2>6.	CUSTOMER CARE</h2>
<p class="subs">You will ensure to carry out the repairs effectively and within the stipulated time agreed with the Client. You will not:
                    (i)	Contact any client without due authorization from SmoothRepairs;

                    (ii)	engage in reckless behaviour while in Client’s Location;

                    (iii)	 cause damage to the Client’s properties; 

                    (iv)	Inflate prices when giving quotations;

                    (v)	receive any money from the Client;

                    (vi)	while acting as a SmoothRepairs Captain be under the influence of alcohol or narcotics;

                    (vii)	take any action or omit to take any action that harms or threatens to harm the safety of Client or any third party; 

                    (viii)	attempt to defraud SmoothRepairs, its Affiliates or Users. If we suspect that you have engaged in fraudulent activity, we may suspend payment of applicable Fees or other payments to you while we conduct an independent investigation into the suspected behaviour. 
                    We reserve the right to take any appropriate measures including but not limited to terminating this Agreement with you, notifying the relevant authorities and/or filing criminal charges against you.
</p>
												
						</div>
					</div>
						<div class="row">
						<div class="col-lg-6 download-right">
							<h2>7. TRAINING FOR ARTISANS</h2>
							<p class="subs">You understand and agree that ICS Outsourcing may interview and provide training to you as an Artisan from time to time. 
							Any such training which ICS Outsourcing provides will be without prejudice to your obligations under this Agreement and ICS Outsourcing will have no responsibility or liability for your acts, performance or behaviour.</p>
        		</div>
						<div class="col-lg-6 download-right">
							<h2>8.	DISCLAIMER</h2>
							<p class="subs">
							    
								The SmoothRepairs platform is provided “as is” and “as available.” ICS Outsourcing and its affiliates disclaim all 
								representations and warranties, express, implied or statutory, not expressly set out in this agreement, including the implied warranties of merchantability, fitness for a particular purpose and non-infringement. </p>
								<p>In addition, ICS Outsourcing and its affiliates make no representation, warranty, or guarantee regarding the reliability, timeliness, quality, suitability or availability of the SmoothRepairs platform or any services or goods requested through the use of 
								the SmoothRepairs platform, or that the SmoothRepairs platform will be uninterrupted or error-free. Neither ICS Outsourcing nor its affiliates guarantee the quality, suitability, safety or ability of users. 
								You agree that the entire risk arising out of your use of the SmoothRepairs platform, and any service or good requested or provided in connection therewith, 
								remain solely with you, to the maximum extent permitted under applicable law.
							</p>
												
						</div>
					</div>
					<div class="row">
						<div class="col-lg-6 download-right">
							<h2>9.	LIMITATION OF LIABILITY</h2>
							<p class="subs">Neither SmoothRepairs nor its affiliates or partners shall be liable for indirect, incidental, special, exemplary, punitive or consequential damages, including lost profits, lost data, personal injury or property damage related to, in connection with, or otherwise resulting from any use of the SmoothRepairs platform, even if SmoothRepairs or its affiliates have been advised of the possibility of such damages. 
							Neither SmoothRepairs nor its affiliates or partners shall be liable for any damages, liability or losses arising out of:
							</p>
							<p>
							    (i)	your use of or reliance on the SmoothRepairs platform or your inability to access or use the SmoothRepairs platform; or 
(ii)	any transaction or relationship between you and any user, even if SmoothRepairs and its affiliates have been advised of the possibility of such damages. </p>
<p>
Neither SmoothRepairs nor its affiliates or partners shall be liable for delay or failure in performance resulting from causes beyond SmoothRepairs reasonable control. 
 You agree that each of SmoothRepairs, its affiliates and its partners have no responsibility or liability to you related to any repair services provided by you to users other than as expressly set forth in this agreement.
</p>
        		</div>
						<div class="col-lg-6 download-right">
							<h2>10.	INDEMNITY</h2>
							<p class="subs">
							    You agree to indemnify and hold ICS Outsourcing and its Affiliates, officers, directors, employees, agents and partners harmless from any and all claims, demands, losses, liabilities, and expenses (including attorneys’ fees) arising out of or in connection with:</p> 
<p>(i)	your use of the SmoothRepairs Platform or services or goods provided through your use of the SmoothRepairs Platform; 
(ii)	your provision of Repairs Services;
(iii)	 your breach or violation of any of this Agreement; or 
(iv)	 your violation of the rights of any third party, including Users.
								</p> 
								<h2>11. TERMINATION</h2>
							<p class="subs">
							    This Agreement may be terminated by either party giving the other two (2) weeks’ notice in advance of its intention to terminate this Agreement.</p> 
<p>SmoothRepairs shall be at liberty to terminate the Agreement forthwith upon breach of any of the terms of this Agreement by the Artisan.</p> 
						</div>
						
					</div>
										<div class="row">
						<div class="col-lg-6 download-right">
							<h2>12.	NOTICE</h2>
							<p class="subs">All notices may be given notice by means of a general notice on the SmoothRepairs Platform, electronic mail to your email address in your Account, or by written communication sent to your address as set forth in your Account. 
							You may give notice to ICS Outsourcing or its Affiliates by written communication to the SmoothRepairs general email address at info@smoothrepairs.com.</p>
						</div>
						<div class="col-lg-6 download-right">
							<h2>13.	GENERAL</h2>
							<p class="subs">You may not assign or transfer this Agreement in whole or in part without getting prior written approval from ICS Outsourcing. 
							You give your approval to ICS Outsourcing for it to assign or transfer this Agreement in whole or in part, including to: 
							    </p> 
							    <p>(i)	a subsidiary or affiliate; 
(ii)	an acquirer of SmoothRepairs equity, business or assets; or 
(iii)	 a successor by merger. No joint venture, partnership, employment or agency relationship exists between you, SmoothRepairs, its Affiliates or any User as a result of the contract between you and SmoothRepairs or use of the SmoothRepairs Platform.
</p>
<p> If any provision of this Agreement is held to be illegal, invalid or unenforceable, in whole or in part, under any law, such provision or part thereof shall to that extent be deemed not to form part of this Agreement but the legality, validity and enforceability of the other provisions in this Agreement shall not be affected. In that event, the parties shall replace the illegal, invalid or unenforceable provision or part thereof with a provision or part thereof that is legal, valid and enforceable and that has, to the greatest extent possible, a similar effect as the illegal, invalid or unenforceable provision or part thereof, given the contents and purpose of this Agreement. </p>
								
						</div>
						
					</div>
					<div class="row">
						<div class="col-lg-6 download-right">
							<h2>14.	ENTIRE AGREEMENT</h2>
							<p class="subs">This Agreement constitutes the entire agreement and understanding of the parties with respect to its subject matter and replaces and supersedes all prior or contemporaneous agreements or undertakings regarding such subject matter. 
							In this Agreement, the words “including” and “include” mean “including, but not limited to.”</p>
						</div>
						<div class="col-lg-6 download-right">
							<h2>15.	GOVERNING LAW</h2>
							<p class="subs">You may not assign or transfer this Agreement in whole or in part without getting prior written approval from ICS Outsourcing. 
							You give your approval to ICS Outsourcing for it to assign or transfer this Agreement in whole or in part, including to: 
							    </p> 
							    
<p>This Agreement shall be governed and construed in accordance with the Laws of the Federal Republic of Nigeria.</p>
								
						</div>
						
					</div>
				</div>	
			</section>
			<!-- End download Area -->			
	
		<!-- /Contact -->
		<!--============================= ADD LISTING =============================-->
     <!--//END CATEGORIES -->
	 
    <!--//END FEATURED PLACES -->
<section class="main-block" light-bg>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="add-listing-wrap">
                        <h2>Reach millions of people</h2>
                        <p>Add your skill in front of millions and earn 3x profits from our listing</p>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="featured-btn-wrap">
                        <a href="artisan.php" class="btn btn-danger"><span class="ti-plus"></span> Signup</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//END ADD LISTING -->
			<?php
		include('footer.php');
		?>
</body>

</html>