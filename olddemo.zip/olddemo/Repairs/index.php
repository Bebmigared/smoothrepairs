<!DOCTYPE html>
<html lang="en">
<?php session_start(); ?>
<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="Colorlib">
    <meta name="description" content="#">
    <meta name="keywords" content="#">
    <!-- Page Title -->
    <title>Get Expert Help From Verified Professionals</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/w3.css">
     <link rel="stylesheet" href="css/w3-theme-red.css">
	<link type="text/css" rel="stylesheet" href="css1/style.css"/>
	<link rel="stylesheet" href="css2/bootstrap.min.css">
	<link rel="stylesheet" href="css2/main.css">
	<link rel="stylesheet" href="css2/font-awesome.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700,900" rel="stylesheet">
    <!-- Simple line Icon -->
    <link rel="stylesheet" href="css/simple-line-icons.css">
    <!-- Themify Icon -->
    <link rel="stylesheet" href="css/themify-icons.css">
    <!-- Hover Effects -->
    <link rel="stylesheet" href="css/set1.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/linearicons.css">
	
	 			
		</head>
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBO0cgbsapmKRr5Sq0BSnVeBNp3XxICpCM&v=3.exp&sensor=false&libraries=places"></script>
		<script>
            function init() {
                var input = document.getElementById('location');
                var autocomplete = new google.maps.places.Autocomplete(input);
                google.maps.event.addListener(autocomplete, 'place_changed',
        function() {
        var place = autocomplete.getPlace();
        var lat = place.geometry.location.lat();
        var lng = place.geometry.location.lng();
        
        document.getElementById("latitude").value = lat
        document.getElementById("longitude").value = lng
   }
);
            }
 
            google.maps.event.addDomListener(window, 'load', init);
        </script>

<body>
    <?php ;
    $categ=$_POST['category'];
    $long=$_POST['longitude'];
    $lati=$_POST['latitude'];
    ?>
    <div class="nav-menu">
        <div class="bg transition">
            <div class="container-fluid fixed">
                <div class="row">
                    <div class="col-md-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="/Repairs"><img src="smoothrepairs_logo.png" class="white" alt="smoothrepairs logo">SmoothRepairs</a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="icon-menu"></span>
              </button>
                            <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item active">
                                        <a class="nav-link" href="#id01" onclick="document.getElementById('id01').style.display='block'">Login</a>
                                    </li>
                                    <li class="nav-item active">
                                        <a class="nav-link btn-danger top-btn" href="artisan.php">Sign up</a>
                                    </li>
                                    
                                    
                                    <!--<li class="nav-item dropdown">
                                        <a class="nav-link" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Pages
                    <span class="icon-arrow-down"></span>
                  </a>
                                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </li>-->
                                    <li class="nav-item active">
                                        <a class="nav-link" href="contact.php">Contact Us</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Blog</a>
                                    </li>
                                   <!--<li><a href="#" class="btn btn-outline-light top-btn"><span class="ti-plus"></span> Add Listing</a></li>-->
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal for Login -->
<div id="id01" class="w3-modal">
    <div class="w3-modal-content w3-card-4 w3-animate-top">
      <header class="w3-container w3-theme-l1"> 
        <span onclick="document.getElementById('id01').style.display='none'"
        class="w3-button w3-display-topright">Close[×]</span>
        <h5>Sign-In to your SmoothRepairs Account</h5>
        </header>
      <div class="w3-padding">
          <div class="col-md-6">
		<div class="contact-form">
        <form method="post" name="">
            <label for="username">Username</label><br>
            <input class="input" id="username" name="username" type="text" placeholder="Enter Username"><br><br>
            <label for="password">Password</label><br>
            <input class="input"  id="password" name="password" type="password" placeholder="Enter Password">
            <br>
            <button class="main-button icon-button pull-right" id="submit" name="submit" type="submit">Sign-In &nbsp;&nbsp;</button>
            <br><br>
            <a href='forgot_pw.php'>Forgot Password?</a>
            <br>

                </form>
                </div>
                </div>
                <?php
    if (isset($_POST['submit']))
        {     
    include("srconfig.php");
    $username=$_POST['username'];
    $password=$_POST['password'];
    $_SESSION['login_user']=$username;
    $query = mysql_query("SELECT * FROM Users WHERE USERNAME='$username' AND PASSWORD='$password' AND STATUS=1");
    $row = mysql_fetch_array($query);
    $_SESSION['username']=$username;
    $_SESSION['loggedIn'] = true;
     if (mysql_num_rows($query) != 0)
    {
     if ($row['USER_TYPE'] =='User')
     {
         echo "<script language='javascript' type='text/javascript'> location.href='user_home.php' </script>";
     }
          if ($row['USER_TYPE']=='Artisan')
     {
         echo "<script language='javascript' type='text/javascript'> location.href='artisan_home.php' </script>";
     }
               if ($row['USER_TYPE']=='Admin')
     {
         echo "<script language='javascript' type='text/javascript'> location.href='home.php' </script>";
     }
     }
      else
      {
    echo "<script type='text/javascript'>alert('Username Or Password Invalid!')</script>";
    echo "<script language='javascript' type='text/javascript'> location.href='index.php' </script>";
    }
    }
    
    ?>
      </div>
      <footer class="w3-container w3-theme-l1">
        <p class="col-lg-8 col-sm-12 footer-text m-0 text-white">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved by <a href="http://www.icsoutsourcing.com" target="_blank">ICS Digital Solutions</a>
						</p>
      </footer>
    </div>
</div>

    <!-- SLIDER -->
    <section class="slider d-flex align-items-center">
        <!-- <img src="images/slider.jpg" class="img-fluid" alt="#"> -->
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-md-12">
                    <div class="slider-title_box">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="slider-content_wrap">
                                    <h1>An Excellent Platfom to Experience First-Class Task Completion</h1>
                                    <h5>We don't stop until all our cliens are satisfied</h5>
                                </div>
                            </div>
                        </div>
                        <div class="row d-flex justify-content-center">
                            <div class="col-md-10">
                                <form class="form-wrap mt-4" method="post" name="" action="search.php?CATEGORY=<?php echo $categ; ?>&LONGITUDE=<?php echo $long; ?>&LATITUDE=<?php echo $lati; ?>">
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <input type="text" placeholder="Hire a Pro?" class="btn-group1">
                                        <input id="location" name="location" type="text" placeholder="Search by City..." onchange="function()"type="text" class="btn-group2">
                                        <button type="submit" class="btn-form"><span class="icon-magnifier search-icon"></span>SEARCH<i class="pe-7s-angle-right"></i></button>
                                    </div>
                                </form>
                                 <input id="longitude" name="longitude" type="text" hidden>
                                 <input id="latitude" name="latitude" type="text" hidden>
                                <div class="slider-link">
                                    <a href="#">Browse Popular</a><span>or</span> <a href="#">Recently Added</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--// SLIDER -->
    <!--//END HEADER -->
    <!--============================= FIND PLACES =============================-->
    
    <!--//END FIND PLACES -->
    <!--============================= FEATURED PLACES =============================-->
   
    <!--============================= CATEGORIES =============================-->
    	<div id="courses" class="section">

			<!-- container -->
			<div class="container">

				<!-- row -->
				
				 <div class="row justify-content-center">
                <div class="col-md-5">
                    <div class="styled-heading">
                        <h3>Browse Categories</h3>
						<p class="lead">Browse Our Awesome Category</p>
                    </div>
                </div>
            </div>
				
				<!-- /row -->

				<!-- courses -->
				<div id="courses-wrapper">

					<!-- row -->
					<div class="row">

						<!-- single course -->
						<?php
     
    include("srconfig.php");

    $sql135 = mysql_query("SELECT * FROM Options WHERE CATEGORY='Artisan' ORDER BY OPTION_NAME limit 8");
while ($row135 = mysql_fetch_array($sql135))
{
echo "<div class='col-md-3 col-sm-6 col-xs-6'>
							<div class='course'>
								<a href='#' class='course-img'>
									<img src='".$row135['image_link']."' alt=''>
									<i class='course-link-icon fa fa-link'></i>
								</a>
								<a class='course-title' href='#'>".$row135['OPTION_NAME']."</a>
								<div class='course-details'>
									<span class='course-price course-free'>".$row135['CATEGORY']."</span>
								</div>
							</div>
						</div>";

}

?>

</div>
</div>
<br>
<br>
						
						<!-- /single course

						<!-- single course
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="course">
								<a href="#" class="course-img">
									<img src="img1/course02.jpg" alt="">
									<i class="course-link-icon fa fa-link"></i>
								</a>
								<a class="course-title" href="#">Introduction to CSS </a>
								<div class="course-details">
									<span class="course-category">Web Design</span>
									<span class="course-price course-premium">Premium</span>
								</div>
							</div>
						</div>
						<!-- /single course

						<!-- single course
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="course">
								<a href="#" class="course-img">
									<img src="img1/course03.jpg" alt="">
									<i class="course-link-icon fa fa-link"></i>
								</a>
								<a class="course-title" href="#">The Ultimate Drawing Course | From Beginner To Advanced</a>
								<div class="course-details">
									<span class="course-category">Drawing</span>
									<span class="course-price course-premium">Premium</span>
								</div>
							</div>
						</div>
						<!-- /single course

						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="course">
								<a href="#" class="course-img">
									<img src="img1/course04.jpg" alt="">
									<i class="course-link-icon fa fa-link"></i>
								</a>
								<a class="course-title" href="#">The Complete Web Development Course</a>
								<div class="course-details">
									<span class="course-category">Web Development</span>
									<span class="course-price course-free">Free</span>
								</div>
							</div>
						</div>
						
							<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="course">
								<a href="#" class="course-img">
									<img src="img1/course04.jpg" alt="">
									<i class="course-link-icon fa fa-link"></i>
								</a>
								<a class="course-title" href="#">The Complete Web Development Course</a>
								<div class="course-details">
									<span class="course-category">Web Development</span>
									<span class="course-price course-free">Free</span>
								</div>
							</div>
						</div>
						<!-- /single course 

					</div>
					<!-- /row 

					<!-- row
					<div class="row">

						<!-- single course
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="course">
								<a href="#" class="course-img">
									<img src="img1/course05.jpg" alt="">
									<i class="course-link-icon fa fa-link"></i>
								</a>
								<a class="course-title" href="#">PHP Tips, Tricks, and Techniques</a>
								<div class="course-details">
									<span class="course-category">Web Development</span>
									<span class="course-price course-free">Free</span>
								</div>
							</div>
						</div>
						<!-- /single course

						<!-- single course 
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="course">
								<a href="#" class="course-img">
									<img src="img1/course06.jpg" alt="">
									<i class="course-link-icon fa fa-link"></i>
								</a>
								<a class="course-title" href="#">All You Need To Know About Web Design</a>
								<div class="course-details">
									<span class="course-category">Web Design</span>
									<span class="course-price course-free">Free</span>
								</div>
							</div>
						</div>
						<!-- /single course

						<!-- single course 
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="course">
								<a href="#" class="course-img">
									<img src="img1/course07.jpg" alt="">
									<i class="course-link-icon fa fa-link"></i>
								</a>
								<a class="course-title" href="#">How to Get Started in Photography</a>
								<div class="course-details">
									<span class="course-category">Photography</span>
									<span class="course-price course-free">Free</span>
								</div>
							</div>
						</div>
						<!-- /single course


						<!-- single course
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="course">
								<a href="#" class="course-img">
									<img src="img1/course08.jpg" alt="">
									<i class="course-link-icon fa fa-link"></i>
								</a>
								<a class="course-title" href="#">Typography From A to Z</a>
								<div class="course-details">
									<span class="course-category">Typography</span>
									<span class="course-price course-free">Free</span>
								</div>
							</div>
						</div>
						<!-- /single course

					</div>
					<!-- /row 

				</div>-->
				<!-- /courses -->
				<div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="featured-btn-wrap">
                        <a href="#" class="btn btn-danger">VIEW ALL CATEGORIES</a>
                    </div>
                </div>
            </div>

			</div>
			<!-- container -->

		</div>
		<!-- /Courses -->
    <!--============================= ADD LISTING =============================-->
    
    <!--//END CATEGORIES -->
	 <section class="main-block light-bg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-5">
                    <div class="styled-heading">
                        <h3>HOW IT WORKS</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 featured-responsive">
                    <div class="featured-place-wrap">
                        
                            <img src="images/featured1.jpg" class="img-fluid" alt="#">
                            <span class="featured-rating-orange">1.0</span>
                            <div class="featured-title-box">
                                <h6>Step 1</h6>
                                <p>Search for a product/service and complete our request form with relevant details <span>• </span></p>
                                
                                 </div>
                    
                    </div>
                </div>
                <div class="col-md-4 featured-responsive">
                    <div class="featured-place-wrap">
                       
                            <img src="images/featured2.jpg" class="img-fluid" alt="#">
                            <span class="featured-rating-green">2.0</span>
                            <div class="featured-title-box">
                                <h6>Step 2</h6>
                                <p>Get a quote for the requested product/service and make payment on our secured platform <span>• </span></p> 
                               
                               
                            </div>
                    
                    </div>
                </div>
                <div class="col-md-4 featured-responsive">
                    <div class="featured-place-wrap">
                      
                            <img src="images/featured3.jpg" class="img-fluid" alt="#">
                            <span class="featured-rating">3.0</span>
                            <div class="featured-title-box">
                                <h6>Step 3</h6>
                                <p>Our professional artisan executes your task and you rate him/her on our platform <span>• </span></p>
                                
                                
                            </div>
                     
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="featured-btn-wrap">
                        <a href="#" class="btn btn-danger">VIEW ALL</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//END FEATURED PLACES -->
<section class="main-block">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="add-listing-wrap">
                        <h2>Reach millions of People</h2>
                        <p>Add your Business infront of millions and earn 3x profits from our listing</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="featured-btn-wrap">
                        <a href="#" class="btn btn-danger"><span class="ti-plus"></span> ADD LISTING</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//END ADD LISTING -->
	<!-- Start download Area -->
			<section class="download-area section-gap" id="app">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 download-left">
							<img class="img-fluid" src="images/d1.png" alt="">
						</div>
						<div class="col-lg-6 download-right">
							<h2>Download the <br>
							Job Listing App Today!</h2>
							<p class="subs">
								It won’t be a bigger problem to find one video game lover in your neighbor. Since the introduction of Virtual Game, it has been achieving great heights so far as its popularity and technological advancement are concerned.
							</p>
							<div class="d-flex flex-row">
								<div class="buttons">
									<i class="fa fa-apple" aria-hidden="true"></i>
									<div class="desc">
										<a href="#">
											<p>
												<span>Available</span> <br>
												on App Store
											</p>
										</a>
									</div>
								</div>
								<div class="buttons">
									<i class="fa fa-android" aria-hidden="true"></i>
									<div class="desc">
										<a href="#">
											<p>
												<span>Available</span> <br>
												on Play Store
											</p>
										</a>
									</div>
								</div>									
							</div>						
						</div>
					</div>
				</div>	
			</section>
			<!-- End download Area -->
			
		<!-- start footer Area -->		
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-3  col-md-12">
							<div class="single-footer-widget">
								<h6>Top Links</h6>
								<ul class="footer-nav">
									<li><a href="#">About Us</a></li>
									<li><a href="#">Contact Us</a></li>
									<li><a href="#">Advertise With Us</a></li>
									<li><a href="#">Support</a></li>
								</ul>
							</div>
						</div>
						<div class="col-lg-3  col-md-12">
							<div class="single-footer-widget">
								<h6>Resources</h6>
								<ul class="footer-nav">
									<li><a href="#">Our Blog</a></li>
									<li><a href="#">FAQs</a></li>
									<li><a href="#"></a></li>
									<li><a href="#">Home</a></li>
								</ul>
							</div>
						</div>
						<div class="col-lg-6  col-md-12">
							<div class="single-footer-widget newsletter">
								<h6>Newsletter</h6>
								<p>You can trust us. we only send promo offers, not a single spam.</p>
								<div id="mc_embed_signup">
									<form target="_blank" novalidate="true" action="" method="post" class="form-inline">

										<div class="form-group row" style="width: 100%">
											<div class="col-lg-8 col-md-12">
											    
												<input name="email" placeholder="Enter Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email '" required="" type="email">
											</div> 
										
											<div class="col-lg-4 col-md-12">
												<button type="submit" name="Subscribe" id="subscribe" class="main-button icon-button pull-right">Subscribe</button>
												<input type="date" name="REG_DATE" placeholder="yyyy-mm-dd" value="<?php echo date("Y-m-d");?>" hidden>
											</div> 
										</div>		
										<div class="info"></div>
									</form>
									<?php
        if (isset($_POST['Subscribe']))
            {
                
        include("srconfig.php");
        session_start();

        $EMAIL=$_POST['email'];
        $REG_DATE=$_POST['REG_DATE'];
        
        $sql1 = mysql_query("INSERT INTO subscribers(email,date_reg,status)VALUES('$EMAIL','$REG_DATE','0')");
        
        sendNotification_User($EMAIL);
        sendNotification_Admin($EMAIL);
        
	    echo "<script type='text/javascript'>alert('Your newsletter subscription was successful')</script>";
        echo "<script language='javascript' type='text/javascript'> location.href='#' </script>";

        } 
        else {

        }
        //Notification Modules Subscribers and Admin
        function sendNotification_Admin($receiver){
        $to = 'info@smoothrepairs.com';
        $subject = "New Email Newsletter Subscription";

        $message = "
        <html>
        <head>
        <title>SmoothRepairs Subscription Signup</title>
        </head>
        <body>
        <p>Dear SmoothRepairs Team,</p>
        <p>You have a new newsletter subscription with the following details:</p>
        <p>$receiver</p>
        <p>Best Regards,</p>
        <br><i>Ayodele Osho,</i>
        <br><strong>COO, SmoothRepairs</strong>
        <br>info@smoothrepairs.com
        <br>Mobile: 08113975299
        
        </body>
        </html>
        ";

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= 'From: SmoothRepairs Admin<info@smoothrepairs.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
        }
        function sendNotification_User($Carrier){
        $to = '$Carrier';
        $subject = "Newsletter Subscription";

        $message = "
        <html>
        <head>
        <title>SmoothRepairs Newsletter Subscription</title>
        </head>
        <body>
        <p>Hello,</p>
        <p>Thank you for signing up as a client on SmoothRepairs. We would love to keep you informed on important notifications, events and promotions when available.</p>
        <p>To do this, kindly click on the 'Yes, subscribe me to this list' button above.</p>
        <p>If you received this email by mistake, simply delete it. You won't be subscribed if you don't click the confirmation link above.</p>
        <p>For questions about this list, please contact info@smoothrepairs.com</p><br/>
        <p>Thank you</p>
        <br>
        <p>Best Regards,</p>
        <br><strong>COO, SmoothRepairs</strong>
        <br>info@smoothrepairs.com
        <br>Mobile: 08113975299
        
        </body>
        </html>
        ";

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= 'From: SmoothRepairs Admin<info@smoothrepairs.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
        }
        ?>
								</div>		
							</div>
						</div>
									
					</div>

					<div class="row footer-bottom d-flex justify-content-between">
						<p class="col-lg-8 col-sm-12 footer-text m-0 text-white">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved by <a href="http://www.icsoutsourcing.com" target="_blank">ICS Digital Solutions</a>
						</p>
						<div class="col-lg-4 col-sm-12 footer-social">
							<ul class="footer-social">
							<li><a href="https://web.facebook.com/SmoothRepairsNG/ " class="facebook"><i class="fa fa-facebook"></i></a></li>
							<li><a href="https://twitter.com/smoothRepairsNG" class="twitter"><i class="fa fa-twitter"></i></a></li>
														<li><a href="http://instagram.com/smoothrepairs" class="instagram"><i class="fa fa-instagram"></i></a></li>
							<li><a href="https://www.linkedin.com/company/smoothrepairs/ " class="linkedin"><i class="fa fa-linkedin"></i></a></li>
						</ul>
						</div>
					</div>
				</div>
			</footer>
			<!-- End footer Area -->	
		
    <!--============================= FOOTER =============================-->
    <!--<footer class="main-block dark-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright">
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0.
                        <p>Copyright &copy; 2018 Listing. All rights reserved | This template is made with <i class="ti-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0.
                        <ul>
                            <li><a href="#"><span class="ti-facebook"></span></a></li>
                            <li><a href="#"><span class="ti-twitter-alt"></span></a></li>
                            <li><a href="#"><span class="ti-instagram"></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>-->
    <!--//END FOOTER -->
<!-- preloader -->
		<div id='preloader'><div class='preloader'></div></div>
		<!-- /preloader -->

<!-- jQuery Plugins -->
		<script type="text/javascript" src="js1/jquery.min.js"></script>
		<script type="text/javascript" src="js1/bootstrap.min.js"></script>
		<script type="text/javascript" src="js1/main.js"></script>

    <!-- jQuery, Bootstrap JS. -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script>
        $(window).scroll(function() {
            // 100 = The point you would like to fade the nav in.

            if ($(window).scrollTop() > 100) {

                $('.fixed').addClass('is-sticky');

            } else {

                $('.fixed').removeClass('is-sticky');

            };
        });
    </script>
</body>

</html>
