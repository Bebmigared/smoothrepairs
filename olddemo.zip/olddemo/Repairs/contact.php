<?php session_start(); ?>
<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
    <!-- Required meta tags -->
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="Colorlib">
    <meta name="description" content="#">
    <meta name="keywords" content="#">
    <!-- Page Title -->
    <title>Get Expert Help From Verified Professionals | Contact Us</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/w3-theme-red.css">
	<link type="text/css" rel="stylesheet" href="css1/style.css"/>
	<link rel="stylesheet" href="css1/font-awesome.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700,900" rel="stylesheet">
    <!-- Simple line Icon -->
    <link rel="stylesheet" href="css/simple-line-icons.css">
    <!-- Themify Icon -->
    <link rel="stylesheet" href="css/themify-icons.css">
    <!-- Hover Effects -->
    <link rel="stylesheet" href="css/set1.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css2/bootstrap.min.css">
	<link rel="stylesheet" href="css2/font-awesome.min.css">
	<link rel="stylesheet" href="css2/main.css">
	</head>
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBO0cgbsapmKRr5Sq0BSnVeBNp3XxICpCM&callback=initMap" async defer></script>
 <script>
      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 19,
          center: {lat: 6.5485889, lng: 3.366240800000014}
        });

        var trafficLayer = new google.maps.TrafficLayer();
        trafficLayer.setMap(map);
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBO0cgbsapmKRr5Sq0BSnVeBNp3XxICpCM&callback=initMap">
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBO0cgbsapmKRr5Sq0BSnVeBNp3XxICpCM&v=3.exp&sensor=false&libraries=places"></script>
        <script>
            function init() {
                var input = document.getElementById('CITY');
                var autocomplete = new google.maps.places.Autocomplete(input);
                google.maps.event.addListener(autocomplete, 'place_changed',
        function() {
        var place = autocomplete.getPlace();
        var lat = place.geometry.location.lat();
        var lng = place.geometry.location.lng();
        
        document.getElementById("LATITUDE").value = lat
        document.getElementById("LONGITUDE").value = lng
   }
);
            }
 
            google.maps.event.addDomListener(window, 'load', init);
        </script>
        <script type="text/javascript">
function changetextbox()
{
    if (document.getElementById("CATEGORY").value == 'Others') {
        document.getElementById("OTHERS").disabled=false;


    }
    if (document.getElementById("CATEGORY").value != 'Others') {
        document.getElementById("OTHERS").disabled=true;


    } 
}
</script>
    <?php
    include("srconfig.php");
?>
<body>
    <div class="nav-menu">
        <div class="bg transition">
            <div class="container-fluid fixed">
                <div class="row">
                    <div class="col-md-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="index.php"><img src="smoothrepairs_logo.png" class="white" alt="smoothrepairs logo">SmoothRepairs</a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="icon-menu"></span>
              </button>
                            <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item active">
                                         <a class="nav-link" href="#id01" onclick="document.getElementById('id01').style.display='block'">Login</a>
                                    </li>
                                    <li class="nav-item active">
                                        <a class="nav-link btn-danger top-btn" href="artisan.php">Sign up</a>
                                    </li>
                                    
                                    
                                    <!--<li class="nav-item dropdown">
                                        <a class="nav-link" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Pages
                    <span class="icon-arrow-down"></span>
                  </a>
                                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </li>-->
                                    <li class="nav-item active">
                                        <a class="nav-link" href="contact.php">Contact Us</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Blog</a>
                                    </li>
                                   <!--<li><a href="#" class="btn btn-outline-light top-btn"><span class="ti-plus"></span> Add Listing</a></li>-->
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
	 <!-- Modal for Login -->
<div id="id01" class="w3-modal">
    <div class="w3-modal-content w3-card-4 w3-animate-top">
      <header class="w3-container w3-theme-l1"> 
        <span onclick="document.getElementById('id01').style.display='none'"
        class="w3-button w3-display-topright">Close[×]</span>
        <h5>Sign-In to your SmoothRepairs Account</h5>
        </header>
      <div class="w3-padding">
          <div class="col-md-6">
		<div class="contact-form">
        <form method="post" name="">
            <label for="username">Username</label><br>
            <input class="input" id="username" name="username" type="text" placeholder="Enter Username"><br><br>
            <label for="password">Password</label><br>
            <input class="input"  id="password" name="password" type="password" placeholder="Enter Password">
            <br>
            <button class="main-button icon-button pull-right" id="submit" name="submit" type="submit">Sign-In &nbsp;&nbsp;</button>
            <br><br>
            <a href='forgot_pw.php'>Forgot Password?</a>
            <br>

                </form>
                </div>
                </div>
                <?php
    if (isset($_POST['submit']))
        {     
    include("srconfig.php");
    $username=$_POST['username'];
    $password=$_POST['password'];
    $_SESSION['login_user']=$username;
    $query = mysql_query("SELECT * FROM Users WHERE USERNAME='$username' AND PASSWORD='$password' AND STATUS=1");
    $row = mysql_fetch_array($query);
    $_SESSION['username']=$username;
    $_SESSION['loggedIn'] = true;
     if (mysql_num_rows($query) != 0)
    {
     if ($row['USER_TYPE'] =='User')
     {
         echo "<script language='javascript' type='text/javascript'> location.href='user_home.php' </script>";
     }
          if ($row['USER_TYPE']=='Artisan')
     {
         echo "<script language='javascript' type='text/javascript'> location.href='artisan_home.php' </script>";
     }
               if ($row['USER_TYPE']=='Admin')
     {
         echo "<script language='javascript' type='text/javascript'> location.href='home.php' </script>";
     }
     }
      else
      {
    echo "<script type='text/javascript'>alert('Username Or Password Invalid!')</script>";
    echo "<script language='javascript' type='text/javascript'> location.href='index.php' </script>";
    }
    }
    
    ?>
      </div>
      <footer class="w3-container w3-theme-l1">
        <p class="col-lg-8 col-sm-12 footer-text m-0 text-white">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved by <a href="http://www.icsoutsourcing.com" target="_blank">ICS Digital Solutions</a>
						</p>
      </footer>
    </div>
</div>

<!-- Hero-area -->
		<div class="hero-area section">

			<!-- Backgound Image -->
			<div class="bg-image bg-parallax overlay" style="background-image:url(img1/page-background.jpg)"></div>
			<!-- /Backgound Image -->

			<div class="container">
				<div class="row">
					<div class="col-md-10 col-md-offset-1 text-center">
						<ul class="hero-area-tree">
						<br/><br/>
							<li><a href="index.php">Home</a></li>
							<li>Contact</li>
						</ul>
						<h1 class="white-text">Get In Touch</h1>

					</div>
				</div>
			</div>

		</div>
		<!-- /Hero-area -->

		<!-- Contact -->
		<div id="contact" class="section">

			<!-- container -->
			<div class="container">

				<!-- row -->
				<div class="row">

					<!-- contact form -->
					<div class="col-md-6">
						<div class="contact-form">
							<h4>Send A Message</h4>
							<form method="post" action="">
								<input class="input" type="text" name="name" placeholder="Name" required>
								<input class="input" type="email" name="email" placeholder="Email" required>
								<input class="input" type="text" name="subject" placeholder="Subject" required>
								<input class="input" type="text" name="phone" placeholder="Mobile No." required>
								<textarea class="input" name="message" placeholder="Enter your Message" required></textarea>
								<input type="date" name="REG_DATE" placeholder="yyyy-mm-dd" value="<?php echo date("Y-m-d");?>" hidden>
								<button type="submit" name="Submit" id="submit" class="main-button icon-button pull-right">Send Message</button>
							</form>
							<?php
        if (isset($_POST['Submit']))
            {
                
        include("srconfig.php");
        session_start();

        $NAME=$_POST['name'];
        $MESSAGE=$_POST['message'];
        $PHONE=$_POST['Phone'];
        $EMAIL=$_POST['email'];
        $SUBJECT=$_POST['subject'];
        $REG_DATE=$_POST['REG_DATE'];
        
        $sql = mysql_query("INSERT INTO contact_us(name,email,phone_no,subject,message,date_reg)VALUES('$NAME','$EMAIL','$PHONE','$SUBJECT','$MESSAGE','$REG_DATE')");
	
	
		$to = 'info@smoothrepairs.com';
        $subject = "$SUBJECT";

        $message = "
        <html>
        <head>
        <title>SmoothRepairs Inquiry for $NAME</title>
        </head>
        <body>
        <p>Dear SmoothRepairs Team,</p>
        <p>$NAME sent in an inquiry on $REG_DATE with the following details:</p>
        <p>$NAME</p>
        <p>$EMAIL</p>
        <p>$PHONE</p>
        <p>$MESSAGE</p>
        <p>Kindly review and contact the inquirer accordingly</p>
        <p>Best Regards,</p>
        <br><i>Ayodele Osho,</i>
        <br><strong>COO, SmoothRepairs</strong>
        <br>info@smoothrepairs.com
        <br>Mobile: 08113975299
        
        </body>
        </html>
        ";

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= 'From: SmoothRepairs Admin<info@smoothrepairs.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
        
        echo "<script type='text/javascript'>alert('Your message has been successfully sent to our SmoothRepairs team and you will be contacted shortly')</script>";
        echo "<script language='javascript' type='text/javascript'> location.href='http://www.smoothrepairs.com/' </script>";

        } 
        else {

        }
        ?>
						</div>
					</div>
					<!-- /contact form -->

					<!-- contact information -->
					<div class="col-md-5 col-md-offset-1">
						<h4>Contact Information</h4>
						<ul class="contact-details">
							<li><i class="fa fa-envelope"></i>info[@]smoothrepairs.com</li>
							<li><i class="fa fa-phone"></i>08113975299</li>
							<li><i class="fa fa-map-marker"></i>6 Olusoji Idowu St, Ilupeju 110001, Lagos</li>
						</ul>

						<!-- contact map -->
						<div id="map"></div>
						<!-- /contact map -->

					</div>
					<!-- contact information -->

				</div>
				<!-- /row -->

			</div>
			<!-- /container -->

		</div>
		<!-- /Contact -->
		<!--============================= ADD LISTING =============================-->
    
				<!-- start footer Area -->		
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-3  col-md-12">
							<div class="single-footer-widget">
								<h6>Top Links</h6>
								<ul class="footer-nav">
									<li><a href="#">About Us</a></li>
									<li><a href="#">Contact Us</a></li>
									<li><a href="#">Advertise With Us</a></li>
									<li><a href="#">Support</a></li>
								</ul>
							</div>
						</div>
						<div class="col-lg-3  col-md-12">
							<div class="single-footer-widget">
								<h6>Resources</h6>
								<ul class="footer-nav">
									<li><a href="#">Our Blog</a></li>
									<li><a href="#">FAQs</a></li>
									<li><a href="#"></a></li>
									<li><a href="#">Home</a></li>
								</ul>
							</div>
						</div>
						<div class="col-lg-6  col-md-12">
							<div class="single-footer-widget newsletter">
								<h6>Newsletter</h6>
								<p>You can trust us. we only send promo offers, not a single spam.</p>
								<div id="mc_embed_signup">
									<form target="_blank" novalidate="true" action="" method="post" class="form-inline">

										<div class="form-group row" style="width: 100%">
											<div class="col-lg-8 col-md-12">
											    
												<input name="email" placeholder="Enter Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email '" required="" type="email">
											</div> 
										
											<div class="col-lg-4 col-md-12">
												<button type="submit" name="Subscribe" id="subscribe" class="main-button icon-button pull-right">Subscribe</button>
												<input type="date" name="REG_DATE" placeholder="yyyy-mm-dd" value="<?php echo date("Y-m-d");?>" hidden>
											</div> 
										</div>		
										<div class="info"></div>
									</form>
									<?php
        if (isset($_POST['Subscribe']))
            {
                
        include("srconfig.php");
        session_start();

        $EMAIL=$_POST['email'];
        $REG_DATE=$_POST['REG_DATE'];
        
        $sql1 = mysql_query("INSERT INTO subscribers(email,date_reg,status)VALUES('$EMAIL','$REG_DATE','0')");
        
        sendNotification_User($EMAIL);
        sendNotification_Admin($EMAIL);
        
	    echo "<script type='text/javascript'>alert('Your newsletter subscription was successful')</script>";
        echo "<script language='javascript' type='text/javascript'> location.href='#' </script>";

        } 
        else {

        }
        //Notification Modules Subscribers and Admin
        function sendNotification_Admin($receiver){
        $to = 'info@smoothrepairs.com';
        $subject = "New Email Newsletter Subscription";

        $message = "
        <html>
        <head>
        <title>SmoothRepairs Subscription Signup</title>
        </head>
        <body>
        <p>Dear SmoothRepairs Team,</p>
        <p>You have a new newsletter subscription with the following details:</p>
        <p>$receiver</p>
        <p>Best Regards,</p>
        <br><i>Ayodele Osho,</i>
        <br><strong>COO, SmoothRepairs</strong>
        <br>info@smoothrepairs.com
        <br>Mobile: 08113975299
        
        </body>
        </html>
        ";

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= 'From: SmoothRepairs Admin<info@smoothrepairs.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
        }
        function sendNotification_User($Carrier){
        $to = '$Carrier';
        $subject = "Newsletter Subscription";

        $message = "
        <html>
        <head>
        <title>SmoothRepairs Newsletter Subscription</title>
        </head>
        <body>
        <p>Hello,</p>
        <p>Thank you for signing up as a client on SmoothRepairs. We would love to keep you informed on important notifications, events and promotions when available.</p>
        <p>To do this, kindly click on the 'Yes, subscribe me to this list' button above.</p>
        <p>If you received this email by mistake, simply delete it. You won't be subscribed if you don't click the confirmation link above.</p>
        <p>For questions about this list, please contact info@smoothrepairs.com</p><br/>
        <p>Thank you</p>
        <br>
        <p>Best Regards,</p>
        <br><strong>COO, SmoothRepairs</strong>
        <br>info@smoothrepairs.com
        <br>Mobile: 08113975299
        
        </body>
        </html>
        ";

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= 'From: SmoothRepairs Admin<info@smoothrepairs.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
        }
        ?>
								</div>		
							</div>
						</div>
									
					</div>

					<div class="row footer-bottom d-flex justify-content-between">
						<p class="col-lg-8 col-sm-12 footer-text m-0 text-white">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						</p>
						<div class="col-lg-4 col-sm-12 footer-social">
							<ul class="footer-social">
							<li><a href="https://web.facebook.com/SmoothRepairsNG/ " class="facebook"><i class="fa fa-facebook"></i></a></li>
							<li><a href="https://twitter.com/smoothRepairsNG" class="twitter"><i class="fa fa-twitter"></i></a></li>
														<li><a href="http://instagram.com/smoothrepairs" class="instagram"><i class="fa fa-instagram"></i></a></li>
							<li><a href="https://www.linkedin.com/company/smoothrepairs/ " class="linkedin"><i class="fa fa-linkedin"></i></a></li>
						</ul>
						</div>
					</div>
				</div>
			</footer>
			<!-- End footer Area -->	
	<!-- preloader -->
		<div id='preloader'><div class='preloader'></div></div>
		<!-- /preloader -->
		<!-- jQuery Plugins -->
		<script type="text/javascript" src="js1/jquery.min.js"></script>
		<script type="text/javascript" src="js1/bootstrap.min.js"></script>
		<script type="text/javascript" src="js1/main.js"></script>




    <!-- jQuery, Bootstrap JS. -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script>
        $(window).scroll(function() {
            // 100 = The point you would like to fade the nav in.

            if ($(window).scrollTop() > 100) {

                $('.fixed').addClass('is-sticky');

            } else {

                $('.fixed').removeClass('is-sticky');

            };
        });
    </script>
</body>

</html>