<?php session_start(); ?>
<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
<title >SmoothRepairs Sign-In</title>

<style>
.boxed
{
    border: 1px solid #D8D8D8;
    margin: auto;


    
    
    
}
    
</style>


<body id="bdy">
<form method="post" name="">
<link rel="stylesheet" type="text/css" href="srstyle.css">
<div class="boxed" style="float: center; height: 250px; margin-top: 180px; width: 420px; font: 12px Calibri; background: #FFFFFF">
        
        <p style="text-align: center; font: 14px Calibri; color: #4169E1; font-weight: bold" >Sign-In to your SmoothRepairs Account</p>
        <br>
        
                    
                            <label for="username" style="margin-left: 60px; font: 12px Calibri; font-weight: bold" >Username</label><br><input id="username" name="username" type="text" placeholder="Enter Username"style="margin-left: 60px; height: 25px; width:300px; border: 1px solid light gray;"><br><br>
                            <label for="password" style="margin-left: 60px; font: 12px Calibri; font-weight: bold">Password</label><br><input id="password" name="password" type="password" placeholder="Enter Password"style="margin-left: 60px; height: 25px; width:300px;  border: 1px solid light gray;"><br><br>
                            <input id="submit" name="submit" type="submit" value="Sign-In" style="margin-left: 60px" >&nbsp;&nbsp;<a href='forgot_pw.php' style="font: 11px Arial" >Forgot Password?</a><br>

                </form>


    <?php
    if (isset($_POST['submit']))
        {     
    include("srconfig.php");
    $username=$_POST['username'];
    $password=$_POST['password'];
    $_SESSION['login_user']=$username;
    $query = mysql_query("SELECT * FROM Users WHERE USERNAME='$username' AND PASSWORD='$password' AND STATUS=1");
    $row = mysql_fetch_array($query);
    $_SESSION['username']=$username;
    $_SESSION['loggedIn'] = true;
     if (mysql_num_rows($query) != 0)
    {
     if ($row['USER_TYPE'] =='User')
     {
         echo "<script language='javascript' type='text/javascript'> location.href='user_home.php' </script>";
     }
          if ($row['USER_TYPE']=='Artisan')
     {
         echo "<script language='javascript' type='text/javascript'> location.href='artisan_home.php' </script>";
     }
               if ($row['USER_TYPE']=='Admin')
     {
         echo "<script language='javascript' type='text/javascript'> location.href='home.php' </script>";
     }
     }
      else
      {
    echo "<script type='text/javascript'>alert('Username Or Password Invalid!')</script>";
    }
    }
    
    ?>
    </body>
    <?php ; ?>