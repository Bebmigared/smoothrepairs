<?php session_start(); ?>
<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
<title >Self Service Home</title>
<?php if($_SESSION['loggedIn']): ?>
<div class="navbar" style="padding-top:5px; font:13px Arial; background:#FF4500; color: #FFFFFF; height:20px; position:fixed; top:0; left:0px; width:100%;">
    <?php
    include("srconfig.php");
    $sql = "SELECT * FROM Users WHERE USERNAME = '" . $_SESSION['username'] . "'";
    $result = mysql_query($sql);
    $row = mysql_fetch_array($result);
    echo "Welcome " . $row['FIRST_NAME'] . " (" . $row['USERNAME'] . ") ";
    ?>
    <?php if($row['USER_TYPE']=='User'): ?>
    <a href="logout.php" style="margin-left: 70%; color: #FFFFFF; text-decoration: none" >Logout</a>
    </div>
    
<style>
.vertical-menu {
    background-color: #696969;
    width: 200px;
    height: 640px;
    position: fixed;
    top:25px;
    left:0px;
}

.vertical-menu a {
    background-color: #696969;
    color: white;
    display: block;
    padding: 8px;
    text-decoration: none;
    font: 13px Arial;
}

.vertical-menu a:hover {
    background-color: #FF4500;
}

.vertical-menu a.active {
    background-color: #FFA500;
    color: white;
}
    
    
    
    
    
</style>    
<br>
<br>
<form method="post" action="">
<link rel="stylesheet" type="text/css" href="srstyle.css">

<div class="vertical-menu">
  <a href="user_home.php" class="active">Home</a>
  <a href="request.php">New Request</a>
  <a href="user_requests.php">My Requests</a>
  <a href="#">My Payments</a>
  <a href="#">Change Password</a>
  <a href="search.php">Find Artisan</a>
</div>


<?php else: ?>
echo "<script type='text/javascript'>alert('Sorry, you do not have permission to access this page!')</script>";
echo "<script language='javascript' type='text/javascript'> location.href='login.php'</script>";
<?php endif; ?>
<?php endif; ?>