<?php session_start(); ?>
<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<?php
include('header.php');
?>
 
<body>
 <?php
include('nav-menu.php');
?><!-- Hero-area -->
		<div class="hero-area section">
			<!-- Backgound Image -->
			<div class="bg-image bg-parallax overlay" style="background-image:url(img1/blog04.jpg)"></div>
			<!-- /Backgound Image -->
			<div class="container">
				<div class="row">
					<div class="col-md-10 col-md-offset-1 text-center">
						<ul class="hero-area-tree">
						<br/><br/>
							<li><a href="index.php">Home</a></li>
							<li>Sign up</li>
						</ul>
						<h1 class="white-text">SmoothRepairs Registration Notification</h1>
					</div>
				</div>
			</div>
		</div>
<section class="main-block">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="add-listing-wrap">
                        <h2>Your Registration was successful</h2>
                         <p>Thanks for choosing <strong>SmoothRepairs</strong>.</p>
                            <p>You will be notified by the admin on the progress of your registration.</p>
                            <p>Welcome to the world of <strong>Unlimited Opportunities</strong>.</p>
                                <p>Best Regards,</p>
                                    <br><i>Ayodele Osho,</i>
                                    <br><strong>COO, SmoothRepairs</strong>
                                    <br>info@smoothrepairs.com
                                    <br>Mobile: 08113975299
                    </div>
                </div>
            </div>
            
        </div>
    </section>
		<?php
		include('footer.php');
		?>
</body>
</html>