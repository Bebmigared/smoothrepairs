<?php session_start(); ?>
<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<?php
include('header.php');
?>
<title >Artisan Verification | SmoothRepairs</title>
<?php if($_SESSION['loggedIn']):?>
<div class="navbar" style="padding-top:5px; font:13px Arial; background:#FF4500; color: #FFFFFF; height:20px; position:fixed; top:0; left:0px; width:100%;">
    <?php
    include("srconfig.php");
    session_start();
    $USERN = $_GET['USERNAME'];
    $sql1 = "SELECT * FROM Users WHERE USERNAME = '" . $_SESSION['username'] . "' OR USERNAME='$USERN'";
    $result1 = mysql_query($sql1);
    $row1 = mysql_fetch_array($result1);
    echo "Welcome, " . $row1['FIRST_NAME'] . " (" . $row1['USERNAME'] . ")";
    ?>
</div>
<script type="text/javascript">
function changetextbox()
{
    if (document.getElementById("TYP").value == 'Individual') {
        document.getElementById("PPP").innerHTML  = 'Artisan Passport Picture ';
        document.getElementById("IDK").innerHTML  = 'Artisan Identity Card ';
    }    
    if (document.getElementById("TYP").value == 'Corporate') {
        document.getElementById("PPP").innerHTML  = 'Company Logo ';
        document.getElementById("IDK").innerHTML  = 'CAC Certificate ';
    }    

}
</script>
<body onload="changetextbox()">
    <?php
    include 'srconfig.php';
?>
<body>
 <?php
include('nav-menu.php');
?><!-- Hero-area -->
		<div class="hero-area section">
			<!-- Backgound Image -->
			<div class="bg-image bg-parallax overlay" style="background-image:url(img1/blog04.jpg)"></div>
			<!-- /Backgound Image -->
			<div class="container">
				<div class="row">
					<div class="col-md-10 col-md-offset-1 text-center">
						<ul class="hero-area-tree">
						<br/><br/>
							<li><a href="index.php">Home</a></li>
							<li>Sign up</li>
						</ul>
						<h1 class="white-text">Artisan's Verification</h1>
					</div>
				</div>
			</div>
		</div>
		<!-- /Hero-area -->
<!-- Contact -->
		<div id="contact" class="section">

			<!-- container -->
			<div class="container">

				<!-- row -->
				<div class="row">

					<!-- contact form -->
					<div class="col-md-8">
						<div class="contact-form">
							<h4>Profile Completion: Artisan's on SmoothRepairs</h4>
<form action="" method="post" enctype="multipart/form-data">
<label>Username:</label>
<input class="input" type="text" name="USERNAME" value="<?php echo  $row1['USERNAME'] ?>" readonly>
<label>Full Name:</label>
<input  class="input" type="text" name="FULL_NAME" value="<?php echo  $row1['LAST_NAME'] ?><?php echo  ' ' .$row1['FIRST_NAME'] ?>" readonly>
<label>Subscription Plan:</label>
<input class="input" type="text" name="ARTISAN_TYPE" value="<?php echo  $row1['ARTISAN_TYPE'] ?>" readonly>
<input type="text" id="TYP" name="ARTISAN_TYPE" value="<?php echo  $row1['ARTISAN_TYPE'] ?>" style="margin-left: 10px; border: transparent;" hidden>
<label id='PPP'>Artisan Passport Picture </label>
<label>(Maximum Size: 30KB)</label>
<input class="input" type="file" name="ARTISAN_PASSPORT" id="ARTISAN_PASSPORT">
<br>
<?php
    Echo "<img src=http://www.smoothrepairs.com/Artisans/".$row1['ARTISAN_PASSPORT']." alt='No Passport/ Logo Uploaded' title='Artisan Passport' height='100' width='95'>"
?>
<br>
<input type="submit" value="Upload Picture" id="submia" name="PPsubmit">
<br>
<label id='IDK'>Artisan Identity Card </label>
<label>(Maximum Size: 50KB)</label>
<input class="input" type="file" name="ARTISAN_IDCARD" id="ARTISAN_IDCARD">
<?php
    Echo "<img src=http://www.smoothrepairs.com/Artisans/".$row1['ARTISAN_IDCARD']." alt='No ID/ Certificate Uploaded' title='Artisan ID' height='100' width='95'>"
?>
<br>
<br>
<input type="submit" value="Upload ID" id="submio" name="IDsubmit">
<br>
<br>
<div class="col-md-12">
<input class="main-button icon-button pull-right" type="submit" id="submit" name="submit" value="Submit">
</div>
<br>
<br>
</form>
        <?php
        if (isset($_POST['submit']))
            {
        include("srconfig.php");
        session_start();
        $UID=$row1['UID'];
        $USERNAME=$row1['USERNAME'];
        $FIRST_NAME=$row1['FIRST_NAME'];
        $MIDDLE_NAME=$row1['MIDDLE_NAME'];
        $LAST_NAME=$row1['LAST_NAME'];
        $CATEGORY=$row1['CATEGORY'];

        if (!empty($_POST)) {
        echo "<script type='text/javascript'>alert('Your SmoothRepairs registration has been completed')</script>";
        $to = "info@smoothrepairs.com";
        $subject = "Artisan Registration for $FIRST_NAME $MIDDLE_NAME $LAST_NAME";
        $message = "
        <html>
        <head>
        <title>Pending Artisan Registration Approval for $USERNAME</title>
        </head>
        <body>
        <p>Dear SmoothRepairs Administrator,</p>
        <p>There is an artisan submission for your attention:</p>
        <br><strong>Artisan:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$FIRST_NAME $MIDDLE_NAME $LAST_NAME
        <br><strong>Username:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$USERNAME
        <br><strong>Category:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$CATEGORY
        <p>Kindly use the following link to view and process the subscription:</p>
        <p><a href='http://www.smoothrepairs.com/user_manager.php?UID=$UID'>Click Here to View Artisan Registration</a></p>
        <br>
        <p>Best Regards,</p>
        <br><i>SmoothRepairs,</i>
        <br><strong>SmoothRepairs</strong>
        <br>info@smoothrepairs.com
        <br>Mobile: 08113975299
        <p>
        </body>
        </html>
        ";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= 'From: ICS Self Service<selfservice@icsoutsourcing.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
        session_destroy();
        echo "<script language='javascript' type='text/javascript'> location.href='/' </script>";
        }
        else 
        {
        echo "<script type='text/javascript'>alert('Invalid Request Submission!')</script>";
        }
        }
        ?>
<?php
$UID=$row1['UID'];
$IDUID=$row1['UID'].PP;
$ARTISAN_PASSPORT=$_FILES["ARTISAN_PASSPORT"]["name"];
$ARTISAN_PASSPORTP=pathinfo($ARTISAN_PASSPORT, PATHINFO_EXTENSION);
$target_dir = "Artisans/";
$target_file = $target_dir . basename($row1['UID']."PP.".pathinfo($ARTISAN_PASSPORT, PATHINFO_EXTENSION));
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($_FILES["ARTISAN_PASSPORT"]["name"],PATHINFO_EXTENSION));
if(isset($_POST["PPsubmit"])) {
    $query6=mysql_query("UPDATE Users SET ARTISAN_PASSPORT='$IDUID.$ARTISAN_PASSPORTP' WHERE UID='$UID'");
    $check = getimagesize($_FILES["ARTISAN_PASSPORT"]["tmp_name"]);
    if($check !== false) {
        echo "<script type='text/javascript'>alert('File is a supported image - " . $check["mime"] . ".')</script>";
        $uploadOk = 1;
    } else {
        echo "<script type='text/javascript'>alert('File is not a supported image.')</script>";
        $uploadOk = 0;
    }

if (file_exists($target_file)) {
    echo "<script type='text/javascript'>alert('Sorry, file already exists.')</script>";
    $uploadOk = 0;
}
if ($_FILES["ARTISAN_IDCARD"]["size"] > 30000) {
    echo "<script type='text/javascript'>alert('Sorry, your file is too large.')</script>";
    $uploadOk = 0;
}
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "<script type='text/javascript'>alert('Sorry, there was an error uploading your file.')</script>Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
if ($uploadOk == 0) {
    echo "<script type='text/javascript'>alert('Sorry, your file was not uploaded.')</script>";
} else {
    if (move_uploaded_file($_FILES["ARTISAN_PASSPORT"]["tmp_name"], $target_file)) {
        echo "<script type='text/javascript'>alert('The file ". basename($_FILES["ARTISAN_PASSPORT"]["name"]). " has been uploaded.')</script>";
    } else {
        echo "<script type='text/javascript'>alert('Sorry, there was an error uploading your file.')</script>";
    }
}
}
?>
<?php
$UID=$row1['UID'];
$IDUID=$row1['UID'].ID;
$ARTISAN_IDCARD=$_FILES["ARTISAN_IDCARD"]["name"];
$ARTISAN_IDCARDP=pathinfo($ARTISAN_IDCARD, PATHINFO_EXTENSION);
$target_dir = "Artisans/";
$target_file = $target_dir . basename($row1['UID']."ID.".pathinfo($ARTISAN_IDCARD, PATHINFO_EXTENSION));
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($_FILES["ARTISAN_IDCARD"]["name"],PATHINFO_EXTENSION));
if(isset($_POST["IDsubmit"])) {
    $query6=mysql_query("UPDATE Users SET ARTISAN_IDCARD='$IDUID.$ARTISAN_IDCARDP' WHERE UID='$UID'");
    $check = getimagesize($_FILES["ARTISAN_IDCARD"]["tmp_name"]);
    if($check !== false) {
        echo "<script type='text/javascript'>alert('File is a supported image - " . $check["mime"] . ".')</script>";
        $uploadOk = 1;
    } else {
        echo "<script type='text/javascript'>alert('File is not a supported image.')</script>";
        $uploadOk = 0;
    }

if (file_exists($target_file)) {
    echo "<script type='text/javascript'>alert('Sorry, file already exists.')</script>";
    $uploadOk = 0;
}
if ($_FILES["ARTISAN_IDCARD"]["size"] > 50000) {
    echo "<script type='text/javascript'>alert('Sorry, your file is too large.')</script>";
    $uploadOk = 0;
}
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "<script type='text/javascript'>alert('Sorry, there was an error uploading your file.')</script>Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
if ($uploadOk == 0) {
    echo "<script type='text/javascript'>alert('Sorry, your file was not uploaded.')</script>";
} else {
    if (move_uploaded_file($_FILES["ARTISAN_IDCARD"]["tmp_name"], $target_file)) {
        echo "<script type='text/javascript'>alert('The file ". basename($_FILES["ARTISAN_IDCARD"]["name"]). " has been uploaded.')</script>";
    } else {
        echo "<script type='text/javascript'>alert('Sorry, there was an error uploading your file.')</script>";
    }
}
}
?>
</div>
					</div>
					<!-- /contact form -->
				</div>
				<!-- /row -->

			</div>
			<!-- /container -->

		</div>
		<!-- /Contact -->
		<?php
		include('footer.php');
		?>
<?php else: ?>
echo "<script type='text/javascript'>alert('Sorry, you are not eligible to make requests on this page!')</script>";
echo "<script language='javascript' type='text/javascript' >location.href='/' </script>";
<?php endif; ?>
</body>
</html>