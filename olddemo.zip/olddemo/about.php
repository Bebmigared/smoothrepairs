<?php session_start(); ?>
<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
<!DOCTYPE html>
<?php
include('header.php');
?>
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBO0cgbsapmKRr5Sq0BSnVeBNp3XxICpCM&callback=initMap" async defer></script>
 <script>
      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 19,
          center: {lat: 6.5485889, lng: 3.366240800000014}
        });

        var trafficLayer = new google.maps.TrafficLayer();
        trafficLayer.setMap(map);
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBO0cgbsapmKRr5Sq0BSnVeBNp3XxICpCM&callback=initMap">
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBO0cgbsapmKRr5Sq0BSnVeBNp3XxICpCM&v=3.exp&sensor=false&libraries=places"></script>
        <script>
            function init() {
                var input = document.getElementById('CITY');
                var autocomplete = new google.maps.places.Autocomplete(input);
                google.maps.event.addListener(autocomplete, 'place_changed',
        function() {
        var place = autocomplete.getPlace();
        var lat = place.geometry.location.lat();
        var lng = place.geometry.location.lng();
        
        document.getElementById("LATITUDE").value = lat
        document.getElementById("LONGITUDE").value = lng
   }
);
            }
 
            google.maps.event.addDomListener(window, 'load', init);
        </script>
        <script type="text/javascript">
function changetextbox()
{
    if (document.getElementById("CATEGORY").value == 'Others') {
        document.getElementById("OTHERS").disabled=false;


    }
    if (document.getElementById("CATEGORY").value != 'Others') {
        document.getElementById("OTHERS").disabled=true;


    } 
}
</script>
    <?php
    include("srconfig.php");
?>
<body>
    <div class="nav-menu">
        <div class="bg transition">
            <div class="container-fluid fixed">
                <div class="row">
                    <div class="col-md-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="/"><img src="smoothrepairs_logo.png" class="white" alt="smoothrepairs logo"></a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="icon-menu"></span>
              </button>
                            <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                   <!-- <li class="nav-item active">
                                         <a class="nav-link" href="#id01" onclick="document.getElementById('id01').style.display='block'">Login</a>
                                    </li>-->
                                    <li class="nav-item active">
                                        <a class="nav-link btn-danger top-btn" href="artisan.php">Sign up</a>
                                    </li>
                                    
                                    
                                    <!--<li class="nav-item dropdown">
                                        <a class="nav-link" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Pages
                    <span class="icon-arrow-down"></span>
                  </a>
                                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </li>-->
                                    <li class="nav-item active">
                                        <a class="nav-link" href="contact.php">Contact Us</a>
                                    </li>
                                    <li class="nav-item active">
                                        <a class="nav-link" href="about.php">About Us</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="/blog">Blog</a>
                                    </li>
                                   <!--<li><a href="#" class="btn btn-outline-light top-btn"><span class="ti-plus"></span> Add Listing</a></li>-->
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>


<!-- Hero-area -->
		<div class="hero-area section">

			<!-- Backgound Image -->
			<div class="bg-image bg-parallax overlay" style="background-image:url(img1/page-background.jpg)"></div>
			<!-- /Backgound Image -->

			<div class="container">
				<div class="row">
					<div class="col-md-10 col-md-offset-1 text-center">
						<ul class="hero-area-tree">
						<br/><br/>
							<li><a href="index.php">Home</a></li>
							<li>About Us</li>
						
						</ul>
						<h1 class="white-text">Why Choose Us</h1>

					</div>
				</div>
			</div>

		</div>
		<!-- /Hero-area -->
		<section class="main-block">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-5">
                    <div class="styled-heading">
                        <h3>Why Choose Us</h3>
                        
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 featured-responsive">
                   <section class="main-block">
        <div class="container">
            <div class="row">
                                <div class="col-md-12">
                                 <div class="row justify-content-left">
                                <h5>An Excellent Platform to Experience First-Class Task Completion<h5><br>
<p>SmoothRepairs is a brand of Integrated Corporate Services Limited, the Business Support Solutions company. When we call out artisans to fix our faulty home/office appliances, not all of us can get the best hands to execute this task. The level of confidence that most Nigerians have in artisans/technicians keeps reducing with each experience with an artisan. That is what brought up the creation of the SmoothRepairs brand. With SmoothRepairs you need not worry about getting creative solutions and exceptional customer experience. SmoothRepairs is synonymous with quality assurance.</p><br>
<p><a href="http://www.icsoutsourcing.com">Integrated Corporate Services Limited</a> has been a leader in Nigeria's outsourcing industry for over two decades. In furtherance of the company’s goal to provide sustainable business solutions, it launched the SmoothRepairs brand to provide maintenance, repair and installation services in a professional and efficient manner. SmoothRepairs is an on-demand service that enables users to request professional artisans/technicians to carry out home and office repairs. Since its establishment in 2017, <a href="https://www.smoothrepairs.com">SmoothRepairs</a> has been helping busy individuals and companies access verified professional artisans for repairs, maintenance and installation services. </p><br>
<p>All our artisans are verified having gone through our background checks. We operate to provide domestic and industrial facilities management solutions at very affordable prices. With SmoothRepairs, individuals and organizations can now focus more on their core business activities while we continue to offer them our premium services. We believe that the time you will expend looking for professional artisans should be saved for other valuable activities.
</p>
                                
                                 </div></div>
                    
                    </div>
                </div>
                
            </div>
            
            </div>
        </div>
    </section>

	
		</div>
		<!-- /Contact -->
		<!--============================= ADD LISTING =============================-->
     <!--//END CATEGORIES -->
	 <section class="main-block light-bg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-5">
                    <div class="styled-heading">
                        <h3>HOW IT WORKS</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 featured-responsive">
                    <div class="featured-place-wrap">
                        
                            <img src="images/featured1.jpg" class="img-fluid" alt="#">
                            <span class="featured-rating-orange">1.0</span>
                            <div class="featured-title-box">
                                <h6>Step 1</h6>
                                <p>Search for a product/service and complete our request form with relevant details <span>• </span></p>
                                <p></p>
                                
                                 </div>
                    
                    </div>
                </div>
                <div class="col-md-4 featured-responsive">
                    <div class="featured-place-wrap">
                       
                            <img src="images/featured2.jpg" class="img-fluid" alt="#">
                            <span class="featured-rating-green">2.0</span>
                            <div class="featured-title-box">
                                <h6>Step 2</h6>
                                <p>Get a quote for the requested product/service and our professional artisan executes your task if you agree to the quote <span>• </span></p> 
                               
                               
                            </div>
                    
                    </div>
                </div>
                <div class="col-md-4 featured-responsive">
                    <div class="featured-place-wrap">
                      
                            <img src="images/featured3.jpg" class="img-fluid" alt="#">
                            <span class="featured-rating">3.0</span>
                            <div class="featured-title-box">
                                <h6>Step 3</h6>
                                <p>You make payment on our secured platform and you rate our artisan accordingly <span>• </span></p>
                                
                                
                            </div>
                     
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="featured-btn-wrap">
                        <a href="#" class="btn btn-danger">GET STARTED</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//END FEATURED PLACES -->
<section class="main-block">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="add-listing-wrap">
                        <h2>Reach millions of people</h2>
                        <p>Add your skill in front of millions and earn 3x profits from our listing</p>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="featured-btn-wrap">
                        <a href="artisan.php" class="btn btn-danger"><span class="ti-plus"></span> Signup</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//END ADD LISTING -->
			<?php
		include('footer.php');
		?>
</body>

</html>