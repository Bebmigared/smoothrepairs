<?php session_start(); ?>
<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<?php
include('header.php');
?>
   <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBO0cgbsapmKRr5Sq0BSnVeBNp3XxICpCM&v=3.exp&sensor=false&libraries=places"></script>
        <script>
            function init() {
                var input = document.getElementById('CITY');
                var autocomplete = new google.maps.places.Autocomplete(input);
                google.maps.event.addListener(autocomplete, 'place_changed',
        function() {
        var place = autocomplete.getPlace();
        var lat = place.geometry.location.lat();
        var lng = place.geometry.location.lng();
        document.getElementById("LATITUDE").value = lat
        document.getElementById("LONGITUDE").value = lng
   }
);
            }
             google.maps.event.addDomListener(window, 'load', init);
        </script>
<script type="text/javascript">
function changetextbox()
{
    if (document.getElementById("CATEGORY").value == 'Others') {
        document.getElementById("OTHERS").disabled=false;
    }
    if (document.getElementById("CATEGORY").value != 'Others') {
        document.getElementById("OTHERS").disabled=true;
    } 
}
</script>
<script type="text/javascript">
    function validateForm()
    {
        var a=document.forms["ArtisanSignup"]["ARTISAN_TYPE"].value;
        var r=document.forms["ArtisanSignup"]["CATEGORY"].value;
        if (r==null || r=="",a==null || a=="")
        {
            alert("Please fill ALL required fields.");
            return false;
        }
    }
</script>
<?php
    include 'srconfig.php';
?>
<body>
 <?php
include('nav-menu.php');
?><!-- Hero-area -->
		<div class="hero-area section">
			<!-- Backgound Image -->
			<div class="bg-image bg-parallax overlay" style="background-image:url(img1/blog04.jpg)"></div>
			<!-- /Backgound Image -->
			<div class="container">
				<div class="row">
					<div class="col-md-10 col-md-offset-1 text-center">
						<ul class="hero-area-tree">
						<br/><br/>
							<li><a href="index.php">Home</a></li>
							<li>Sign up</li>
						</ul>
						<h1 class="white-text">Artisan's Sign Up</h1>
					</div>
				</div>
			</div>
		</div>
		<!-- /Hero-area -->
<!-- /Hero-area -->
		<!-- Contact -->
		<div id="contact" class="section">

			<!-- container -->
			<div class="container">

				<!-- row -->
				<div class="row">

					<!-- contact form -->
					<div class="col-md-8">
						<div class="contact-form">
							<h3>Sign up To Become an Artisan on SmoothRepairs</h3>
							<form method="post" name="ArtisanSignup" onsubmit="return validateForm()" action="" >
<label for="FIRST_NAME">First Name</label>
<input class="input" type="text" name="FIRST_NAME" id="txtbx" placeholder="First Name..." required>
<label for="LAST_NAME">Last Name</label>
<input class="input" type="text" name="LAST_NAME" id="txtbxs" placeholder="Last Name..." required>
<label for="Gender">Gender</label><br>
<select class="input"  name="Gender" required>
<option value="">Gender</option>  
<?php 
$sql135 = mysql_query("SELECT OPTION_NAME FROM Options WHERE CATEGORY='Gender' ORDER BY OPTION_NAME");
while ($row135 = mysql_fetch_array($sql135)){
echo "<option value='". $row135['OPTION_NAME'] ."'>" . $row135['OPTION_NAME'] . "</option>";
}
?>
"</option>"</select>
<br>
<label for="CATEGORY">Category</label>
<br>
<select class="input" name="CATEGORY" id="CATEGORY" placeholder="Select Category..." onchange="changetextbox()" required>
<option value="">Please Specify</option>    
<?php
$sql133 = mysql_query("SELECT OPTION_NAME FROM Options WHERE CATEGORY='Artisan' ORDER BY OPTION_NAME");
while ($row133 = mysql_fetch_array($sql133)){
echo "<option value='". $row133['OPTION_NAME'] ."'>" . $row133['OPTION_NAME'] . "</option>";
}
?>
"</option>"</select>
<br>
<label for="MOBILE">Mobile Phone</label>
<input class="input" type="text" name="MOBILE" id="txtbx" placeholder="Phone..." required>
<label for="EMAIL">E-mail Address</label>
<input class="input" type="text" name="EMAIL" placeholder="E-mail Address..." id="txtbxs" required>
<label for="Qualification">Qualification</label>
<select class="input" name="qualification" required>
<option value="">Artisan's Qualification:</option>
<?php 
$sql138 = mysql_query("SELECT OPTION_NAME FROM Options WHERE CATEGORY='Qualification' ORDER BY OPTION_NAME");
while ($row138 = mysql_fetch_array($sql138)){
echo "<option value='". $row138['OPTION_NAME'] ."'>" . $row138['OPTION_NAME'] . "</option>";
}
?>
"</option>"
</select>
<br>
<label for="Experience">Experience</label>
<select class="input" name="experience" required>
<option value="">Years of Experience:</option>
<?php 
$sql138 = mysql_query("SELECT OPTION_NAME FROM Options WHERE CATEGORY='Experience' ORDER BY OPTION_NAME");
while ($row138 = mysql_fetch_array($sql138)){
echo "<option value='". $row138['OPTION_NAME'] ."'>" . $row138['OPTION_NAME'] . "</option>";
}
?>
"</option>"
</select>
<input class="input" type="date" name="REG_DATE" placeholder="yyyy-mm-dd" value="<?php echo date("Y-m-d");?>" hidden>
<input class="input" type="text" name="LONGITUDE" id="LONGITUDE" oninput="this.className = ''" hidden>
<input class="input" type="text" name="LATITUDE" id="LATITUDE" oninput="this.className = ''" hidden>
<br>
<label for="STATE">Location</label>
<select class="input" name="STATE" placeholder="Select Category..." required>
<option value="">Select State:</option>
<?php 
$sql138 = mysql_query("SELECT OPTION_NAME FROM Options WHERE CATEGORY='States' ORDER BY OPTION_NAME");
while ($row138 = mysql_fetch_array($sql138)){
echo "<option value='". $row138['OPTION_NAME'] ."'>" . $row138['OPTION_NAME'] . "</option>";
}
?>
"</option>"
</select>
<br>
<br>
<div class="col-md-12">
    <button class="main-button icon-button pull-left" name="mBack" id="submitb"><a href="/">Back</a></button>
     <button class="main-button icon-button pull-right" type="submit" name="Submit" id="submit" value="Continue">Become an Artisan</button></div>
</form>
<?php
if (isset($_POST['Submit']))
            {
        include("srconfig.php");
        session_start();
        $FIRST_NAME=$_POST['FIRST_NAME'];
        $LAST_NAME=$_POST['LAST_NAME'];
        $ARTISAN_TYPE=$_POST['ARTISAN_TYPE'];
        //$USERNAME=$_POST['USERNAME'];
        $EMAIL=$_POST['EMAIL'];
        //$PASSWORD=$_POST['PASSWORD'];
        $MOBILE=$_POST['MOBILE'];
        $CATEGORY=$_POST['CATEGORY'];
        //$COMPANY_NAME=$_POST['COMPANY_NAME'];
        //$CITY=$_POST['CITY'];
        $STATE=$_POST['STATE'];
        $REG_DATE=$_POST['REG_DATE'];
        //$ADDRESS_LINE_1=$_POST['ADDRESS_LINE_1'];
        //$ADDRESS_LINE_2=$_POST['ADDRESS_LINE_2'];
        $Qual = $_POST['qualification'];
        $Gender = $_POST['Gender'];
        $Experience = $_POST['experience'];
                        // check for duplicate entries
            $check_phone=mysql_query("SELECT * FROM Users WHERE MOBILE='$MOBILE'");
            
            $check_phone_exist = mysql_fetch_array($check_phone);
          
            if(($check_phone_exist['MOBILE']==$MOBILE))
            {
                echo "<script type='text/javascript'>alert('An Error Occurred: Phone Number already exist, Try again with a different Phone number')</script>";
            }
            else
            {
                     $query = mysql_query("INSERT INTO Users (FIRST_NAME,LAST_NAME,ARTISAN_TYPE,STATE,USER_TYPE,EMAIL,CATEGORY,MOBILE,REG_DATE,QUALIFICATION,GENDER,EXPERIENCE) VALUES ('$FIRST_NAME','$LAST_NAME','Individual','$STATE','Artisan','$EMAIL','$CATEGORY','$MOBILE','$REG_DATE','$Qual','$Gender','$Experience')") or die(mysql_error());
                    //$row = mysql_fetch_array($query);
                   
                  if ($query) 
                        {
                                    echo "<script type='text/javascript'>alert('Your SmoothRepairs registration has been submitted successfully')</script>";
                                    echo "<script language='javascript' type='text/javascript'> location.href='thank-you' </script>";
                                     $to = $EMAIL;
                                 $subject = "SmoothRepairs Artisan Registration for $FIRST_NAME $LAST_NAME";
                                 $message = "
        <html>
        <head>
        <title>SmoothRepairs Registration Notification</title>
        </head>
        <body>
        <p>Dear $FIRST_NAME,</p>
        <p>Thanks for choosing <strong>SmoothRepairs</strong>.</p>
        <p>You will be notified by the admin on the progress of your registration.</p>
        <p>Welcome to the world of <strong>Unlimited Opportunities</strong>.</p>
        <p>Best Regards,</p>
        <br><i>Ayodele Osho,</i>
        <br><strong>COO, SmoothRepairs</strong>
        <br>info@smoothrepairs.com
        <br>Mobile: 08113975299
        </body>
        </html>
        ";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= 'From: SmoothRepairs Admin<info@smoothrepairs.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
        }
        else
        {
             echo "<script type='text/javascript'>alert('Your SmoothRepairs registration was not successful at this time, please try again later')</script>";
        }
        }
                }
        else {
            // do nothing
        }
        ?>					</div>
					</div>
					<!-- /contact form -->
				</div>
				<!-- /row -->

			</div>
			<!-- /container -->

		</div>
		<!-- /Contact -->
		<?php
		include('footer.php');
		?>
</body>
</html>