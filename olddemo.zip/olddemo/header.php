<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content ="width=device-width,initial-scale=1,user-scalable=yes" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
    <meta name="author" content="SmoothRepairs">
    <meta name="description" content="AC & Gen Repairs in Lagos Nigeria, Professional Artisans Platform, service providers in your neighborhood at a price that fits your budget on SmoothRepairs.">
    <meta name="keywords" content="AC & Gen Repairs in Lagos, Nigeria , Professional Artisans Platform, Hire Local Service Professionals, Artisans in Lagos, Discover Businesses and Services at SmoothRepairs™, 
    Experienced, Tested, Trusted Artisans at Your Fingertips Artisans in Lagos, Nigeria, Professionals and Experts Hire, Request for Artisans on SmoothRepairs, Body Massage, AC Repair and Technician,Background Check,Carpenter,Computer Repairer,
    Electrician,Fumigation,Generator Repairs and Servicing,Home Services,Search for a product/service and complete our request form with relevant details">
    <meta name="Robots" content="index, follow" />
    <meta property="og:title" content="AC & Gen Repairs in Nigeria | Professional Artisans"/>
<meta property="og:url" content="https://www.smoothrepairs.com"/>
<meta property="og:type" content="website"/>
<meta property="og:description" content="AC & Gen Repairs in Lagos Nigeria, Professional Artisans Platform, service providers in your neighborhood at a price that fits your budget SmoothRepairs."/>
<meta property="og:image" content="https://www.smoothrepairs.com/images/slider.jpg"/>
<meta name="google-site-verification" content="vu8dHIU_UCieN6k60B2v2U9DCRQvdlVu8yX6wb93bxs" />
<meta name="yandex-verification" content="3b9dbd5355d28092" />
    <!-- Page Title -->
    <title>AC & Gen Repairs in Nigeria | Professional Artisans</title>
    <!-- Bootstrap CSS -->
    <link rel="shortcut icon" type="image/x-icon" href="Smoothrepairs_favicon.jpg" />
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
	<link type="text/css" rel="stylesheet" href="css1/style.css"/>
	<link rel="stylesheet" href="css2/bootstrap.min.css">
	<link rel="stylesheet" href="css2/main.css">
	<link rel="stylesheet" href="css2/font-awesome.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700,900" rel="stylesheet">
    <!-- Simple line Icon -->
    <link rel="stylesheet" href="css/simple-line-icons.css">
    <!-- Themify Icon -->
    <link rel="stylesheet" href="css/themify-icons.css">
    <!-- Hover Effects -->
    <link rel="stylesheet" href="css/set1.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/linearicons.css">
	<link rel="stylesheet" href="css/w3.css" type="text/css">
<link rel="stylesheet" href="css/w3-theme-red.css" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
	<script type='application/ld+json'> 
            {
            "@context": "http://www.schema.org",
            "@type": "Organization",
            "name": "SmoothRepairs",
            "url": "https://www.smoothrepairs.com",
            "logo": "https://www.smoothrepairs.com/smoothrepairs_logo.png",
            "description": "Hire professional local service providers in your neighborhood at a price that fits your budget. SmoothRepairs is an Excellent Platform to Experience First-Class Task Completion. We don't stop until all our clients are satisfied. Experienced, Tested, Trusted Artisans at Your Fingertips",
            "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "+2348113975286",
            "contactType": "Customer Support"
               },
            "sameAs": [
            "https://web.facebook.com/SmoothRepairsNG/",
            "https://twitter.com/smoothRepairsNG",
            "https://www.linkedin.com/company/smoothrepairs/",
            "http://instagram.com/smoothrepairs"
            ]
            }
        </script>

        <script type='application/ld+json'> 
            {
            "@context": "http://www.schema.org",
            "@type": "WebSite",
            "name": "SmoothRepairs",
            "url": "https://www.smoothrepairs.com",
            "potentialAction": {
            "@type": "SearchAction",
            "target": "http://www.smoothrepairs.com/search.php?keywords={search_term_string}",
            "query-input": "required name=search_term_string"
                 
                 
                  }
            }
        </script>

        <script type="application/ld+json">
            {
            "@context": "http://schema.org",
            "@type": "WebPage",
            "hasPart":[ 
            {
                "@type":"SiteNavigationElement",
                "name":"Get Expert Help From Verified Professionals | SmoothRepairs",
                "url": "http://www.careernaija.com/"
             },{
                "@type":"SiteNavigationElement",
                "name":"Contact Us",
                "url": "https://www.smoothrepairs.com/contact.php"
             },{
                "@type":"SiteNavigationElement",
                "name":"Login",
                "url": "https://www.smoothrepairs.com/login.php"
             },{
                "@type":"SiteNavigationElement",
                "name":"Sign Up",
                "url": "https://www.smoothrepairs.com/artisan.php"
             },
             {
                "@type":"SiteNavigationElement",
                "name":"LinkedIn Profile Writing",
                "url": "http://www.smoothrepairs.com/linkedin"
             }
            ]
        }
        </script>
        <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5afd44535f7cdf4f05344ca5/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

 <?php include('gtm.php'); ?>
</head>
