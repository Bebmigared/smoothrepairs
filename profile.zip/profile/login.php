<?php
/*
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
*/
?>
<html>
    <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="smoothrepairs">
    <meta name="author" content="Assets repair">
    <meta name="keywords" content="Repairing">
    
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <link href="vendor/vector-map/jqvmap.min.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

    <title>SmoothRepairs - Login</title>
</head>

<body style="background-image: linear-gradient(1deg, #9d00ff54 0%, #17a2b8ab 85%, #007bff 95%);">
    <div class="container">
        <div class="row" style="height: 200px;"></div>
        <div class="row" style="text-align:center; padding-left:500px;">
            <div class="col-sm-5">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Sign In</h3>
                        <br>
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post" name="">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Username" name="username" type="text" required autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" required>
                                </div>
                                                               
                                <!-- Change this to a button or input when using this as a form -->
                                <input class="btn btn-lg btn-success btn-block" id="submit" name="submit" type="submit" value="Login">
                                <br>
                                <a href="forgot_pw.php">Forgot Password?</a><br>
                            </fieldset>
                        </form>
                        <?php

                        if (isset($_SESSION['login'])) {
    // Redirection to login page twitter or facebook
    header("location: index2.php");
    }


    if (isset($_POST['submit']))
        {     
    include("sbconfig.php");

    $username=$_POST['username'];
    $password=$_POST['password'];

   /* $_SESSION['login_user']=$username;
    $query = mysqli_query($db, "SELECT * FROM Users WHERE email='$username' AND password='$password'");
    $row = mysqli_fetch_array($query);
    $_SESSION['last_login'] = $row['last_login'];
    $_SESSION['username']= $username;*/

    //$query = "SELECT * FROM users WHERE email = '$username' AND password = '$password'";
        
    $login = mysqli_query($db, "SELECT * FROM users WHERE email = '$username' AND password = '$password'") or die(mysqli_error($db));
    $row ="";
		//$result = mysqli_fetch_array($login);
        //$row = mysqli_fetch_array($query);
        $row  = mysqli_fetch_array($login);
if(is_array($row)) {
    //session_start();
    $_SESSION['login'] = $row;
$_SESSION["id"] = $row[2];
//$_SESSION['name'] = 'Micheal';
header ('location: index2.php');
}


        //if (mysqli_num_rows($login) > 0) {

            //if ($result) {
            //echo "<script type='text/javascript'>alert('Login successful!')</script>";
            //echo "<script type='text/javascript'>alert('Login successful!')</script>";
            //$result = mysqli_fetch_array($login);
            
            //$_SESSION["login"] = $rowval;
          //  $_SESSION['user'] = "";
            //$_SESSION['user'] = $result;
            //$_SESSION['new'] ="Micheal";

            //<?=$_SESSION['user']['firstname']

            

            //$_SESSION['Login'] = $username;
            //$_SESSION['success'] = "You are now logged in";
		    //header ('location: index.php');
            // set new last login
            
            //echo "<script type='text/javascript'> location.href='index.php' </script>";
            //echo "<script language='javascript' type='text/javascript'> location.href='index.php' </script>";
            //window.location.replace("index.php");
            
            
            #}

        //}
        else {
            # code...
            echo "<script type='text/javascript'>alert('Invalid Login details!')</script>";
        }


        }
     
    
        ?>

                    </div>
                </div>
        </div>

        <div class="row"></div>
</div>
    </div>

</body>

</html>
