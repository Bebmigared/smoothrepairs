<!DOCTYPE html>
<html>
    <head>
        <title>SmoothRepairs Subscriber's Request</title>
        <meta http-equiv="refresh" content="0; url=index2.php" />
    </head>
    <body>
        <!--window.location.replace("index2.html");-->
    </body>
</html>
