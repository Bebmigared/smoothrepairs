=== Coralina Lite ===
Contributors: spoot1986
Tags: blog, news, two-columns, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, translation-ready
Requires at least: 4.5
Tested up to: 5.0.3
Requires PHP: 5.2.4
Stable tag: 1.0.0
Version: 1.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Coralina Lite is a simple WordPress theme for the blogging and news site. Lightweight and elegant design will make your web project irresistible.

* Google Mobile Friendly & Google Structured Data Tested
* Font awesome support
* SEO Optimized
* Cross browser support
* Mobile adaptive
* Simple and Friendly theme options panel
* WPML support
* Multisite support

== Installation ==

1. Copy the theme folder to /wp-content/themes/
2. Activate the theme

== Frequently Asked Questions ==
 
If you have any question you can write me (spoot@bk.ru)

== Screenshots ==
 
1. screenshot.png

== Resources ==

1 - Font Awesome - https://fontawesome.com
    Font License:
    ======
	Applies to all desktop and webfont files in the following directory: font-awesome/fonts/.
	License: SIL OFL 1.1
	URL: http://scripts.sil.org/OFL

	Code License:
    ===========
	Applies to all CSS and LESS files in the following directories: font-awesome/css/, font-awesome/less/, and font-awesome/scss/.
	License: MIT License
	URL: http://opensource.org/licenses/mit-license.html

2 - Lazy Load - https://appelsiini.net/projects/lazyload
	Copyright Mika Tuupola, MIT License 

3 - Swiper - http://www.idangero.us/swiper/
	Copyright Vladimir Kharlampidi, MIT License

4 - WOW - https://github.com/matthieua/WOW/
	Copyright Matt Dellac, GNU GPLv3

5 - Font Awesome Icon Picker - hhttps://farbelous.github.io/fontawesome-iconpicker/
	Copyright Javi Aguilar, MIT License

6 - Images used from pxhere.com
    pxhere provides images under CC0 license 
    (https://creativecommons.org/publicdomain/zero/1.0/)

    Images:	
    Screenshot: 
        https://pxhere.com/ru/photo/998134
        https://pxhere.com/ru/photo/1430899

== Changelog ==

= 1.0.0 =
* Released: November 06, 2018
*Initial release

= 1.0.1 =
* Released: January 20, 2019
*Fixed the bugs

= 1.0.2 =
* Released: January 21, 2019
*Fixed the bugs

= 1.0.3 =
* Released: January 22, 2019
*Fixed the bugs

= 1.0.4 =
* Released: January 23, 2019
*Fixed the bugs

= 1.0.5 =
* Released: January 24, 2019
*Fixed the bugs

= 1.0.6 =
* Released: February 07, 2019
*Fixed the bugs