<?php
/**
 * The template for displaying the footer
 */
?>

<!--begin footer-->
<footer class="footer">
	<div class="container">
		<div class="row">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">

				<!--begin menu-->
				<nav id="bottom-navigation" class="bottom-navigation" role="navigation">
					
					<?php
	    				wp_nav_menu( array(
	    					'container'       => 'ul',
	    					'theme_location'  => 'bottom-menu',
	    					'menu_id'         => '',
	    					'menu_class'	  => 'nav',	
	    					'depth'           => 1,
	    				) );
	    			?>
					
				</nav>
				<!--end menu-->

				<?php $copyright_text = get_theme_mod('copyright_text');?>
				<p><?php echo wp_kses_post($copyright_text);?></p>

				<?php if(is_active_sidebar('footer-social')):?>
					<div class="social">
						<?php dynamic_sidebar('footer-social'); ?>
					</div>	
				<?php endif; ?>
				
			</div>	
		</div>
	</div>		
</footer>
<!--end footer-->

<div class="to-top"><i class="fas fa-chevron-up" aria-hidden="true"></i></div>

<?php wp_footer(); ?>

</body>
</html>
