<?php
/*
 * The template for displaying all single posts
 */

get_header();
$full_width_post = get_theme_mod('full_width_post'); 
coralina_get_breadcrumbs(get_the_ID());
?>

<div class="site-content container pt-4 pb-4">
	<div class="row">
		<div class="primary <?php if($full_width_post == 1){echo "col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12";} else {echo "col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12";}?>">

			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class('post');?>>
					<div class="entry-content">
						<?php the_content();?>
					</div>
					<?php coralina_get_entry_meta();?>
				</article>

				<?php
				
				if (comments_open() || get_comments_number()){
					comments_template();
				}
								
			endwhile; ?>
			
		</div>

		<?php if($full_width_post != 1):?>
		<div class="secondary col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
			<?php get_sidebar();?>
		</div>
		<?php endif?>
		
	</div>	
</div>
<?php 
get_footer();