<?php
/*
 * The template for displaying 404 pages (not found)
 */

get_header(); ?>
<div class="site-content page-404-content">
	<div class="page-404">
		<div class="wrapper-404">
			<div class="border-404">
				<p class="h1"><?php esc_html_e('404', 'coralina-lite')?></p>
				<p class="desc"><?php esc_html_e('Page not found', 'coralina-lite')?></p>
			</div>	
		</div>	
	</div>
</div>			
<?php
get_footer();